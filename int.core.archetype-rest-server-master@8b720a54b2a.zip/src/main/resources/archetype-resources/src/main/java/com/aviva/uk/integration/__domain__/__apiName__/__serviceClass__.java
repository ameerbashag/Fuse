package com.aviva.uk.integration.${domain}.${apiName};

import javax.annotation.security.RolesAllowed;
import javax.ws.rs.${httpMethod};
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

public class ${serviceClass} {
	
	@RolesAllowed("${roles}")
	@${httpMethod}
	@Path("${servicePath}")
	@Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML, MediaType.TEXT_XML, "application/problem+json" })
	public void ${apiName}() {
		// this does nothing -- just a shell for CXF and Camel
	}	
	
}
