# REST API Archetype
This archetype creates a skeleton REST API implementation which you can use to build your API.  It will provide the following:

* Automatically generate your project to the correct naming standards
* Create the resource class in the correct package structure
* Create a basic camel config file
* Create a POM with the bare basics to get going

The latest version reduces the amount of refactoring you need to do to get the generated project ready to use, by asking for additional data when creating the project.

## Usage
Archetype details:

Group Id | Artifact Id | Version
---------|-------------|--------
com.aviva.uk.integration | archetype-rest-server | Use latest Version

### IDE
You can use your IDE of choice to create a new project from the Archetype.  You will be prompted to enter some additional details documented below.  For more info on how to do this in your IDE, refer to the IDE documentation.

### Maven
You can use the following maven command if you prefer.  Remember to use the appropriate version, if in doubt, use the latest version.  You can put whatever value you like for the -DartifactId option, as this will be overriden by the extra details you will be prompted for.

```
mvn archetype:generate -DarchetypeGroupId=com.aviva.uk.integration -DarchetypeArtifactId=archetype-rest-server -DarchetypeVersion=<version> -DgroupId=com.aviva.uk.integration -DartifactId=dummy
```

### Required Fields
You will be prompted to enter some additional fields:

Field | Description
------|------------
serviceClass | Enter the name of the class which provides the JAX-RS description of your service.  Do not add '.java' as this will be created automatically for you
roles | Enter the role name required for your API
httpMethod | The HTTP method for your API, i.e. GET, POST etc.  **Must be uppercase**
servicePath | The value which will be used for the @PATH annotation.
apiName | Your api name **in lower case**.  Used to construct package names, and configuration items in the camel config and pom
domain | The domain name **in lower case**.
scmUrl | The url of the GIT repository.  This will be added to the POM
