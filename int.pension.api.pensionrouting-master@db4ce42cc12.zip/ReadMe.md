# Pension Domain Routing Bundles

This repository contains two Fuse Bundles for the Pension Profile managed in the following sub-directories:

  * pension-api-router
  * pensionDocumentsRouter
 

## Fuse Bundle Overview for _pension-api-router_
  Could the 'owner/architect' for the **PensionRouter** please make themselves known and update this section with a summary of the scope of the Bundle and how it is used with the sub-resources of the **PensionPlan** resource.  Can they also include links to any design documentation please?

## Fuse Bundle Overview for _pensionDocumentsRouter_
  Could the 'owner/architect' for the **PensionDocumentsRouter** please make themselves known and update this section with a summary of the scope of the Bundle and how it is used wit the sub-resources of the **PensionPlan** resource.  Can they also include links to any design documentation please?  


### Update Process
Given the number of teams the and number of APIs being exposed via the CXF endpoints defined by these two projects, the risk of changes impacting on downstream dependent APIs in the Pension profile, is high.
For this reason we are introducing a limited level of control by restricting access to the _master_ branch to the security group [UK.Integration.Gatekeepers](https://confluence.aviva.co.uk/pages/viewpage.action?spaceKey=DIG&title=Git#Git-SecurityGroups). 

All changes should be made via a _Feature_ branch associated with a Jira task containing a clear description of the change requirement.  Once this task has been completed, the _Feature_ branch should be merged into _master_ by way of a _Pull Request_ (PR).  PRs should be approved by two reviewers familiar with the project and the reasons behind the change.  Reviwers are responsible for verifying the quality and integratory of any changes made and by approving the PR they are confirming that:

  * impacts on other projects and users of the artefacts built from the _master_ branch have been considered and made aware where necessary
  * the _master_ branch will continue to build successfully in it's CI pipeline

Once both reviewers have approved the PR then anyone one of the security group [UK.Integration.Gatekeepers](https://confluence.aviva.co.uk/pages/viewpage.action?spaceKey=DIG&title=Git#Git-SecurityGroups) will be free to make the merge.


### Continuous Integration Workflow


The **PensionRouter** is built and released by this [Jenkins Build Pipeline](http://jenkins-pd.via.novonet/view/Integration/view/Pension/view/Pipelines/view/PensionRouting/) which clones from the master branch.

The **PensionDocumentsRouter** is built and released by this [Jenkins Build Pipeline](http://jenkins-pd.via.novonet/view/Integration/view/Pension/view/Pipelines/view/PensionDocumentRouting/) which also clones from the master branch.

