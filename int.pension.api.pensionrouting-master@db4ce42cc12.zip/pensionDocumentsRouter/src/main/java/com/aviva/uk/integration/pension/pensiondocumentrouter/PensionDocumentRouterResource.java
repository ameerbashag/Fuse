package com.aviva.uk.integration.pension.pensiondocumentrouter;

import javax.annotation.security.RolesAllowed;
import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.apache.cxf.jaxrs.ext.multipart.MultipartBody;

public class PensionDocumentRouterResource {

	@RolesAllowed("pension-read")
	@POST
	@Path("/transferOutConfirmation")
	@Consumes({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON })
	@Produces({ MediaType.MULTIPART_FORM_DATA, "application/problem+json",
			"application/problem+xml" })
	public MultipartBody transferOutConfirmation(Object request) {
		// this does nothing -- just a shell for CXF and Camel
		return null;
	}

	@RolesAllowed("pension-read")
	@POST
	@Path("/pclsConfirmation")
	@Consumes({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON })
	@Produces({ MediaType.MULTIPART_FORM_DATA, "application/problem+json",
			"application/problem+xml" })
	public MultipartBody pclsConfirmation(Object request) {
		// this does nothing -- just a shell for CXF and Camel
		return null;
	}

	@RolesAllowed("pension-read")
	@POST
	@Path("/policyInformationDocumentData")
	@Consumes({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON })
	@Produces({ MediaType.MULTIPART_FORM_DATA, "application/problem+json",
			"application/problem+xml" })
	public MultipartBody policyInformationDocumentData(Object request) {
		// this does nothing -- just a shell for CXF and Camel
		return null;
	}
}
