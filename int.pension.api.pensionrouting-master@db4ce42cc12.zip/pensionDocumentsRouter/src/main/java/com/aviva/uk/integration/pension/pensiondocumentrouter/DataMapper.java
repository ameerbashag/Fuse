package com.aviva.uk.integration.pension.pensiondocumentrouter;

import javax.ws.rs.core.Response.Status;

import org.apache.camel.Body;
import org.apache.camel.Exchange;
import org.apache.cxf.common.util.StringUtils;
import org.apache.cxf.jaxrs.ext.multipart.MultipartBody;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.aviva.uk.integration.errorhandling.ProblemDetailsException;

/**
 * This class provides the functionality to handle the request/response from/to API consumer
 * 
 * @author CHEEKAS
 * 
 */
public class DataMapper {

    private static final Logger LOG = LoggerFactory.getLogger(DataMapper.class);

    public void handleResourceNotFound(Exchange exchange) throws ProblemDetailsException {
        String path = (String) exchange.getIn().getHeader(Exchange.HTTP_PATH);

        if (!StringUtils.isEmpty(path) && path.indexOf("/") >= 0) {
            path = path.substring(1); // exclude / from subresource name
        }
        LOG.error("Requested resource not found" + path);
        throw new ProblemDetailsException(Status.NOT_FOUND, "Resource '" + path + "' not found");
    }

    public MultipartBody mapResponse(Exchange exchange, @Body MultipartBody response) throws ProblemDetailsException {
        exchange.getIn().setHeader(Exchange.CONTENT_TYPE, "multipart/form-data");
        if (response == null) {
            LOG.error("Response from transferoutconfirmation is null...");
        }
        return response;
    }

}
