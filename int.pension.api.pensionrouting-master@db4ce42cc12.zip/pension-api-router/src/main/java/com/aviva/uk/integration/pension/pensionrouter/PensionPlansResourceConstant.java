package com.aviva.uk.integration.pension.pensionrouter;

import java.util.HashMap;
import java.util.Map;

public class PensionPlansResourceConstant {

    public static final Map<String, String[]> subResourceTable;
    static {
        subResourceTable = new HashMap<String, String[]>();

        subResourceTable.put("pensionProducts", new String[] { "GET" });
        subResourceTable.put("planholders", new String[] { "GET" });
        subResourceTable.put("funds", new String[] { "GET" });
        subResourceTable.put("valuationSummaries", new String[] { "GET" });
        subResourceTable.put("projectionDataSummary", new String[] { "GET" });
        subResourceTable.put("currentPerformance", new String[] { "GET" });
        subResourceTable.put("fundChoices", new String[] { "GET" });
        subResourceTable.put("fundHoldings", new String[] { "GET" });
        subResourceTable.put("monetaryTransactions", new String[] { "GET" });
        subResourceTable.put("monetaryTransactionSummaries", new String[] { "GET" });
        subResourceTable.put("monetaryTransactionTotals", new String[] { "GET" });
        subResourceTable.put("latestContributions", new String[] { "GET" });
        subResourceTable.put("nextContributions", new String[] { "GET" });
        subResourceTable.put("lifeCoverInstructions", new String[] { "GET" });
        subResourceTable.put("regularContributionInstructions", new String[] { "GET" });
        subResourceTable.put("investmentStrategies", new String[] { "GET" });
        subResourceTable.put("loyaltyBonuses", new String[] { "GET" });
        subResourceTable.put("valuations", new String[] { "GET" });
        subResourceTable.put("conventionalValuations", new String[] { "GET" });
        subResourceTable.put("groupPensionSummaries", new String[] { "GET" });
        subResourceTable.put("projectionData", new String[] { "GET" });
        subResourceTable.put("projection", new String[] { "POST" });
        subResourceTable.put("ipfunddetails", new String[] { "GET" });
        subResourceTable.put("roles", new String[] { "GET", "POST" });
        subResourceTable.put("end", new String[] { "POST" });
        subResourceTable.put("charges", new String[] { "GET" });
        subResourceTable.put("bankDetails", new String[] { "GET" });
    }

}