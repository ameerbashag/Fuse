package com.aviva.uk.integration.pension.projection.bo;

import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;
import org.codehaus.jackson.annotate.JsonPropertyOrder;
import org.codehaus.jackson.map.annotate.JsonSerialize;

@XmlRootElement(name = "projectedIncomeDrawdownFunds")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(propOrder = { "fundDetails"})
@JsonPropertyOrder({ "fundDetails"})
@JsonSerialize(include = JsonSerialize.Inclusion.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class ProjectedIncomeDrawdownFunds {
	
	private List<FundDetails> fundDetails;

	public List<FundDetails> getFundDetails() {
		return fundDetails;
	}

	public void setFundDetails(List<FundDetails> fundDetails) {
		this.fundDetails = fundDetails;
	}	
	
	@Override
	public String toString() {
		return "ClassPojo [fundDetails = " + fundDetails + "]";
	}
}
