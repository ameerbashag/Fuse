package com.aviva.uk.integration.pension.projection.bo;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;
import org.codehaus.jackson.annotate.JsonProperty;
import org.codehaus.jackson.annotate.JsonPropertyOrder;
import org.codehaus.jackson.map.annotate.JsonSerialize;

@XmlRootElement(name = "fundDetails")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(propOrder = { "pointInTimeType", "pointInTime", "lowFundAmount",
		"midFundAmount", "highFundAmount" })
@JsonPropertyOrder({ "pointInTimeType", "pointInTime", "lowFundAmount",
		"midFundAmount", "highFundAmount" })
@JsonSerialize(include = JsonSerialize.Inclusion.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class FundDetails {

	@XmlElement(name = "midFundAmount")
	@JsonProperty(value = "midFundAmount")
	private CurrencyAmount midFundAmount;
	
	@XmlElement(name = "highFundAmount")
	@JsonProperty(value = "highFundAmount")
	private CurrencyAmount highFundAmount;
	
	@XmlElement(name = "pointInTimeType")
	@JsonProperty(value = "pointInTimeType")
	private String pointInTimeType;
	
	@XmlElement(name = "pointInTime")
	@JsonProperty(value = "pointInTime")
	private int pointInTime;
	
	@XmlElement(name = "lowFundAmount")
	@JsonProperty(value = "lowFundAmount")
	private CurrencyAmount lowFundAmount;
	
	public String getPointInTimeType() {
		return pointInTimeType;
	}
	public void setPointInTimeType(String pointInTimeType) {
		this.pointInTimeType = pointInTimeType;
	}
	public int getPointInTime() {
		return pointInTime;
	}
	public void setPointInTime(int pointInTime) {
		this.pointInTime = pointInTime;
	}
	public CurrencyAmount getLowFundAmount() {
		return lowFundAmount;
	}
	public void setLowFundAmount(CurrencyAmount lowFundAmount) {
		this.lowFundAmount = lowFundAmount;
	}
	public CurrencyAmount getMidFundAmount() {
		return midFundAmount;
	}
	public void setMidFundAmount(CurrencyAmount midFundAmount) {
		this.midFundAmount = midFundAmount;
	}
	public CurrencyAmount getHighFundAmount() {
		return highFundAmount;
	}
	public void setHighFundAmount(CurrencyAmount highFundAmount) {
		this.highFundAmount = highFundAmount;
	}

}
