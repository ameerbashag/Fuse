package com.aviva.uk.integration.pension.pensionrouter;

import java.util.HashMap;
import java.util.Map;

public class PensionRouterConstant {

    public static final Map<String, String> routingTable;
    static {
        routingTable = new HashMap<String, String>();
        routingTable.put("pensionProducts", "direct-vm:pensionProducts?synchronous=true");
        routingTable.put("planholders", "direct-vm:planholders");
        routingTable.put("funds", "direct-vm:funds");
        routingTable.put("valuationSummaries", "direct-vm:ValuationSummary");
        routingTable.put("projectionDataSummary", "direct-vm:projectionDataSummary");
        routingTable.put("getPensionProducts", "direct-vm:pensionProducts?synchronous=true");
        routingTable.put("getPlanholders", "direct-vm:planholders");
        routingTable.put("getFunds", "direct-vm:funds");
        routingTable.put("getValuationSummary", "direct-vm:ValuationSummary");
        routingTable.put("getProjectionDataSummary", "direct-vm:projectionDataSummary");
        routingTable.put("currentPerformance", "direct-vm:currentPerformance");
        routingTable.put("fundChoices", "direct-vm:fundChoices");
        routingTable.put("fundHoldings", "direct-vm:fundHoldings");
        routingTable.put("monetaryTransactions", "direct-vm:monetaryTransaction");
        routingTable.put("monetaryTransactionSummaries", "direct-vm:monetaryTransactionSummaries");
        routingTable.put("getFundChoicesResource", "direct-vm:fundChoices");
        routingTable.put("getFundHoldings", "direct-vm:fundHoldings");
        routingTable.put("getMonetaryTransactions", "direct-vm:monetaryTransaction");
        routingTable.put("monetartyTransactionSummaries", "direct-vm:monetaryTransactionSummaries");
        routingTable.put("monetaryTransactionTotals", "direct-vm:monetaryTransactionTotals");
        routingTable.put("latestContributions", "direct-vm:contributions");
        routingTable.put("nextContributions", "direct-vm:contributions");
        routingTable.put("lifeCoverInstructions", "direct-vm:lifeCoverInstructions");
        routingTable.put("regularContributionInstructions", "direct-vm:regularContributionInstructions");
        routingTable.put("investmentStrategies", "direct-vm:investmentStrategies");
        routingTable.put("loyaltyBonuses", "direct-vm:loyaltyBonuses");
        routingTable.put("valuations", "direct-vm:valuations");
        routingTable.put("conventionalValuations", "direct-vm:conventionalValuations");
        routingTable.put("groupPensionSummaries", "direct-vm:groupPensionSummaries");
        routingTable.put("projectionData", "direct-vm:pension-api-projectionData");
        routingTable.put("projection", "direct-vm:pension-api-projection");
        routingTable.put("ipfunddetails", "direct-vm:ipfunddetails");
        routingTable.put("roles", "direct-vm:pension-api-roles");
        routingTable.put("getLatestContributions", "direct-vm:contributions");
        routingTable.put("getNextContributions", "direct-vm:contributions");
        routingTable.put("getLifeCoverInstructions", "direct-vm:lifeCoverInstructions");
        routingTable.put("getRegularContributionInstructions", "direct-vm:regularContributionInstructions");
        routingTable.put("getRegularInvestmentStrategies", "direct-vm:investmentStrategies");
        routingTable.put("getLoyaltyBonuses", "direct-vm:loyaltyBonuses");
        routingTable.put("getValuations", "direct-vm:valuations");
        routingTable.put("getConventionalValuations", "direct-vm:conventionalValuations");
        routingTable.put("getGroupPensionSummaries", "direct-vm:groupPensionSummaries");
        routingTable.put("getPensionProjectionData", "direct-vm:pension-api-projectionData");
        routingTable.put("getPensionProjection", "direct-vm:pension-api-projection");
        routingTable.put("getIpFundDetails", "direct-vm:ipfunddetails");
        routingTable.put("getPensionRoles", "direct-vm:pension-api-roles");
        routingTable.put("addPensionRoles", "direct-vm:pension-api-roles-post");
        routingTable.put("endPensionRoles", "direct-vm:pension-api-roles-post");
        routingTable.put("pensionPlan", "direct-vm:pensionPlans");
        routingTable.put("getPensionCharges", "direct-vm:pension-api-charges");
        routingTable.put("getBankDetails", "direct-vm:bankDetails");
    }

}
