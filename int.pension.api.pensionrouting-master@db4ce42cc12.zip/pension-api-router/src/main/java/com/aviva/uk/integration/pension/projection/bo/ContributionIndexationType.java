package com.aviva.uk.integration.pension.projection.bo;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;

import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.lang.StringUtils;
import org.codehaus.jackson.annotate.JsonValue;

@XmlType(name = "ContributionIndexationType")
@XmlEnum
public enum ContributionIndexationType {

    @XmlEnumValue("Level")
    LEVEL("Level", "Level", "Level"),

    @XmlEnumValue("Fixed")
    FIXED("Fixed Percentage", "Fixed", "Fixed"),

    @XmlEnumValue("AverageWeeklyEarnings")
    AVERAGE_WEEKLY_EARNINGS("Average Earnings Index", "AverageWeeklyEarnings", "AverageWeeklyEarnings"),

    @XmlEnumValue("RetailPricesIndex")
    RETAIL_PRICES_INDEX("Retail Prices Index", "RetailPricesIndex", null);

    private static final String[] IGNORED = { "salary related" };

    private final String bancsResponseValue;
    private final String unisureResponseValue;
    private final String projectionResponseValue;

    ContributionIndexationType(String bancsResponseValue, String projectionResponseValue, String unisureResponseValue) {
        this.bancsResponseValue = bancsResponseValue;
        this.projectionResponseValue = projectionResponseValue;
        this.unisureResponseValue = unisureResponseValue;
    }

    @JsonValue
    public String value() {
        return projectionResponseValue;
    }

    public static ContributionIndexationType fromBancsResponse(String bancsResponse) {
        if (isIgnored(bancsResponse)) {
            return null;
        }

        for (ContributionIndexationType indexationType : ContributionIndexationType.values()) {
            if (indexationType.bancsResponseValue.equals(bancsResponse)) {
                return indexationType;
            }
        }
        throw new IllegalArgumentException(bancsResponse);
    }

    public static ContributionIndexationType fromUnisureResponse(String unisureResponse) {
        if (isIgnored(unisureResponse)) {
            return null;
        }

        for (ContributionIndexationType indexationType : ContributionIndexationType.values()) {
            if (StringUtils.equals(indexationType.unisureResponseValue, unisureResponse)) {
                return indexationType;
            }
        }
        throw new IllegalArgumentException(unisureResponse);
    }

    private static boolean isIgnored(String bancsResponse) {
        return ArrayUtils.contains(IGNORED, bancsResponse.toLowerCase());
    }
}
