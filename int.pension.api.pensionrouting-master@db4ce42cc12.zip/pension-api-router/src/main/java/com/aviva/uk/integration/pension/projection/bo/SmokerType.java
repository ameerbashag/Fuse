package com.aviva.uk.integration.pension.projection.bo;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;

import org.codehaus.jackson.annotate.JsonCreator;
import org.codehaus.jackson.annotate.JsonValue;

@XmlType(name = "SmokerType")
@XmlEnum
public enum SmokerType {

    @XmlEnumValue("SetByCrusader")
    SET_BY_CRUSADER("SetByCrusader"), @XmlEnumValue("UnknownExt")
    UNKNOWN_EXT("UnknownExt"), @XmlEnumValue("Unknown")
    UNKNOWN("Unknown"), @XmlEnumValue("NeverSmokedExt")
    NEVER_SMOKED_EXT("NeverSmokedExt"), @XmlEnumValue("NeverSmoked")
    NEVER_SMOKED("NeverSmoked"), @XmlEnumValue("QuitSmokingExt")
    QUIT_SMOKING_EXT("QuitSmokingExt"), @XmlEnumValue("QuitSmoking")
    QUIT_SMOKING("QuitSmoking"), @XmlEnumValue("CurrentSmokerExt")
    CURRENT_SMOKER_EXT("CurrentSmokerExt"), @XmlEnumValue("CurrentSmoker")
    CURRENT_SMOKER("CurrentSmoker");
    private final String value;

    SmokerType(String v) {
        value = v;
    }

    @JsonValue
    public String value() {
        return value;
    }

    @JsonCreator
    public static SmokerType fromValue(String v) {
        for (final SmokerType c : SmokerType.values()) {
            if (c.value.equalsIgnoreCase(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
