package com.aviva.uk.integration.pension.projection.bo;

import java.math.BigDecimal;
import java.util.Currency;
import java.util.Locale;

/**
 * @author ma317300
 *
 */
public class CurrencyAmount {

    private BigDecimal amount;
    private String currency = Currency.getInstance(Locale.UK).getCurrencyCode();

    public BigDecimal getAmount() {
        return amount;
    }

    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }

    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }

}
