/*
 * Copyright (c) 2015 AVIVA.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of AVIVA
 * ("Confidential Information").  
 * You shall not disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with AVIVA.
 */
package com.aviva.uk.integration.pension.interceptor;

import java.util.Arrays;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.cxf.interceptor.Fault;
import org.apache.cxf.message.Message;
import org.apache.cxf.phase.AbstractPhaseInterceptor;
import org.apache.cxf.phase.Phase;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.aviva.uk.integration.pension.pensionrouter.PensionPlansResourceConstant;

/**
 * PensionInInterceptor called during POST STREAM phase to check for missing
 * planNumber in the request
 * 
 * @author APPUR
 *
 */
public class PensionInInterceptor extends AbstractPhaseInterceptor<Message> {

	private final static Logger LOG = LoggerFactory.getLogger(PensionInInterceptor.class);
	private final static String REQUEST_URI = "org.apache.cxf.request.uri";
	private final static String HTTP_REQUEST_METHOD = "org.apache.cxf.request.method";

	/**
	 * Constructor to call this Interceptor during the POST_STREAM Phase
	 */
	public PensionInInterceptor() {

		super(Phase.POST_STREAM);

	}

	/**
	 * handleMessage method checks for missing planNumber in the request
	 * contained in {@link Message}
	 */
	@Override
	public void handleMessage(Message message) throws Fault {

		LOG.info(">>> Entered InInterceptor");

		String uri = message.get(REQUEST_URI).toString();
		String httpMethod = message.get(HTTP_REQUEST_METHOD).toString();

		String resource = uri.substring(uri.lastIndexOf("pensionPlans"));
		Pattern subResourceRequest = Pattern.compile("pensionPlans\\/.+\\/.+");
		Pattern absentPlanNumber = Pattern.compile("pensionPlans[\\/]?");
		Matcher m = subResourceRequest.matcher(resource);
		String subResource = uri.substring(uri.lastIndexOf("/") + 1);
		// Check the SubResource Request matches with Resource
		if (m.matches()) {

			// Check the SubResource exists in Resources Table
			if (null != PensionPlansResourceConstant.subResourceTable.get(subResource)
					&& PensionPlansResourceConstant.subResourceTable.get(subResource).length != 0) {
				String[] methodNames = PensionPlansResourceConstant.subResourceTable.get(subResource);
				// Check the Requested HTTP method related to SubResource not
				// exists in Resources Table
				if (!Arrays.asList(methodNames).contains(httpMethod)) {
					throwFault("Sub-Resource is not recognised");
				}
				// SubResource not exists in Resources table
			} else {
				throwFault("Sub-Resource is not recognised");
			}
		}

		if (uri.contains("/pensionPlans//") || absentPlanNumber.matcher(resource).matches()) {
			throwFault("PlanNumber missing");
		}
		if ((uri.contains("/pensionPlans/"+subResource) && PensionPlansResourceConstant.subResourceTable.containsKey(subResource))) {
			throwFault("Request Malformed, missing plan number");
		}
	}

	public void throwFault(String detail) {
		LOG.info(">>> PlanNumber missing");

		Fault fault = new Fault(new Exception(detail));

		fault.setStatusCode(400);

		LOG.info(">>> Throwing Interceptor Fault");

		throw fault;
	}
}
