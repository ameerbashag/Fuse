package com.aviva.uk.integration.pension.projection.bo;

import java.math.BigDecimal;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;

import org.codehaus.jackson.map.annotate.JsonSerialize;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(propOrder = { "contributionIndexationRate", "contributionIndexationType", "indexationAppliesIndicator",
        "mvrMaxCarryForwardAllowanceIndicator", "premiumPayingIndicator", "salaryBasedContributionsIndicator",
        "withProfitsFundHoldingIndicator", "paymentFrequency" })
@JsonSerialize(include = JsonSerialize.Inclusion.NON_NULL)
public class ProjectionAssumptions {

    private BigDecimal contributionIndexationRate;
    private ContributionIndexationType contributionIndexationType;
    private String indexationAppliesIndicator;
    private String mvrMaxCarryForwardAllowanceIndicator;
    private String premiumPayingIndicator;
    private String salaryBasedContributionsIndicator;
    private String withProfitsFundHoldingIndicator;
    private PaymentFrequency paymentFrequency;

    public BigDecimal getContributionIndexationRate() {
        return contributionIndexationRate;
    }

    public void setContributionIndexationRate(BigDecimal contributionIndexationRate) {
        this.contributionIndexationRate = contributionIndexationRate;
    }

    public ContributionIndexationType getContributionIndexationType() {
        return contributionIndexationType;
    }

    public void setContributionIndexationType(ContributionIndexationType contributionIndexationType) {
        this.contributionIndexationType = contributionIndexationType;
    }

    public String getIndexationAppliesIndicator() {
        return indexationAppliesIndicator;
    }

    public void setIndexationAppliesIndicator(String indexationAppliesIndicator) {
        this.indexationAppliesIndicator = indexationAppliesIndicator;
    }

    public String getMvrMaxCarryForwardAllowanceIndicator() {
        return mvrMaxCarryForwardAllowanceIndicator;
    }

    public void setMvrMaxCarryForwardAllowanceIndicator(String mvrMaxCarryForwardAllowanceIndicator) {
        this.mvrMaxCarryForwardAllowanceIndicator = mvrMaxCarryForwardAllowanceIndicator;
    }

    public String getPremiumPayingIndicator() {
        return premiumPayingIndicator;
    }

    public void setPremiumPayingIndicator(String premiumPayingIndicator) {
        this.premiumPayingIndicator = premiumPayingIndicator;
    }

    public String getSalaryBasedContributionsIndicator() {
        return salaryBasedContributionsIndicator;
    }

    public void setSalaryBasedContributionsIndicator(String salaryBasedContributionsIndicator) {
        this.salaryBasedContributionsIndicator = salaryBasedContributionsIndicator;
    }

    public String getWithProfitsFundHoldingIndicator() {
        return withProfitsFundHoldingIndicator;
    }

    public void setWithProfitsFundHoldingIndicator(String withProfitsFundHoldingIndicator) {
        this.withProfitsFundHoldingIndicator = withProfitsFundHoldingIndicator;
    }

    public PaymentFrequency getPaymentFrequency() {
        return paymentFrequency;
    }

    public void setPaymentFrequency(PaymentFrequency paymentFrequency) {
        this.paymentFrequency = paymentFrequency;
    }

}
