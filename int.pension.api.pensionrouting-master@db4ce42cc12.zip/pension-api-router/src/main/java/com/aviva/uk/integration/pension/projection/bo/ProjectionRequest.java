package com.aviva.uk.integration.pension.projection.bo;

import java.math.BigDecimal;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;
import org.codehaus.jackson.map.annotate.JsonSerialize;

@XmlRootElement(name = "pensionProjectionRequest")
@XmlAccessorType(XmlAccessType.FIELD)
@JsonSerialize(include = JsonSerialize.Inclusion.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class ProjectionRequest {

    private QuotationType quotationType;
    private String quotationDate;
    private Gender namedSecondGender;
    private String namedSecondDateOfBirth;
    private SmokerType namedSecondSmokerType;
    private PaymentFrequency paymentFrequency;
    private PaymentTiming paymentTiming;
    private int guarantee;
    private BigDecimal beneficiaryPercentage;
    private EscalationBasis escalationBasis;
    private BigDecimal escalationRate;
    // private String planNumber;
    private String drawdownProjectionDate;
    private BigDecimal pclsWithdrawalPercentage; 
    private int alternativeRetirementAge;
    private String alternativeRetirementDate;
    private BigDecimal alternativePersonalPayment;
    private BigDecimal alternativeEmployerPayment;
    

    public String getDrawdownProjectionDate() {
		return drawdownProjectionDate;
	}

	public void setDrawdownProjectionDate(String drawdownProjectionDate) {
		this.drawdownProjectionDate = drawdownProjectionDate;
	}

	public BigDecimal getPclsWithdrawalPercentage() {
		return pclsWithdrawalPercentage;
	}

	public void setPclsWithdrawalPercentage(BigDecimal pclsWithdrawalPercentage) {
		this.pclsWithdrawalPercentage = pclsWithdrawalPercentage;
	}


    public QuotationType getQuotationType() {
        return quotationType;
    }

    public void setQuotationType(QuotationType quotationType) {
        this.quotationType = quotationType;
    }

    public String getQuotationDate() {
        return quotationDate;
    }

    public void setQuotationDate(String quotationDate) {
        this.quotationDate = quotationDate;
    }

    public Gender getNamedSecondGender() {
        return namedSecondGender;
    }

    public void setNamedSecondGender(Gender namedSecondGender) {
        this.namedSecondGender = namedSecondGender;
    }

    public String getNamedSecondDateOfBirth() {
        return namedSecondDateOfBirth;
    }

    public void setNamedSecondDateOfBirth(String namedSecondDateOfBirth) {
        this.namedSecondDateOfBirth = namedSecondDateOfBirth;
    }

    public SmokerType getNamedSecondSmokerType() {
        return namedSecondSmokerType;
    }

    public void setNamedSecondSmokerType(SmokerType namedSecondSmokerType) {
        this.namedSecondSmokerType = namedSecondSmokerType;
    }

    public PaymentFrequency getPaymentFrequency() {
        return paymentFrequency;
    }

    public void setPaymentFrequency(PaymentFrequency paymentFrequency) {
        this.paymentFrequency = paymentFrequency;
    }

    public PaymentTiming getPaymentTiming() {
        return paymentTiming;
    }

    public void setPaymentTiming(PaymentTiming paymentTiming) {
        this.paymentTiming = paymentTiming;
    }

    public int getGuarantee() {
        return guarantee;
    }

    public void setGuarantee(int guarantee) {
        this.guarantee = guarantee;
    }

    public BigDecimal getBeneficiaryPercentage() {
        return beneficiaryPercentage;
    }

    public void setBeneficiaryPercentage(BigDecimal beneficiaryPercentage) {
        this.beneficiaryPercentage = beneficiaryPercentage;
    }

    public EscalationBasis getEscalationBasis() {
        return escalationBasis;
    }

    public void setEscalationBasis(EscalationBasis escalationBasis) {
        this.escalationBasis = escalationBasis;
    }

    public BigDecimal getEscalationRate() {
        return escalationRate;
    }

    public void setEscalationRate(BigDecimal escalationRate) {
        this.escalationRate = escalationRate;
    }

    public int getAlternativeRetirementAge() {
        return alternativeRetirementAge;
    }

    public void setAlternativeRetirementAge(int alternativeRetirementAge) {
        this.alternativeRetirementAge = alternativeRetirementAge;
    }

    public String getAlternativeRetirementDate() {
        return alternativeRetirementDate;
    }

    public void setAlternativeRetirementDate(String alternativeRetirementDate) {
        this.alternativeRetirementDate = alternativeRetirementDate;
    }

    public BigDecimal getAlternativePersonalPayment() {
        return alternativePersonalPayment;
    }

    public void setAlternativePersonalPayment(BigDecimal alternativePersonalPayment) {
        this.alternativePersonalPayment = alternativePersonalPayment;
    }

    public BigDecimal getAlternativeEmployerPayment() {
        return alternativeEmployerPayment;
    }

    public void setAlternativeEmployerPayment(BigDecimal alternativeEmployerPayment) {
        this.alternativeEmployerPayment = alternativeEmployerPayment;
    }

	@Override
	public String toString() {
		return "ProjectionRequest [quotationType=" + quotationType
				+ ", quotationDate=" + quotationDate + ", namedSecondGender="
				+ namedSecondGender + ", namedSecondDateOfBirth="
				+ namedSecondDateOfBirth + ", namedSecondSmokerType="
				+ namedSecondSmokerType + ", paymentFrequency="
				+ paymentFrequency + ", paymentTiming=" + paymentTiming
				+ ", guarantee=" + guarantee + ", beneficiaryPercentage="
				+ beneficiaryPercentage + ", escalationBasis="
				+ escalationBasis + ", escalationRate=" + escalationRate
				+ ", drawdownProjectionDate=" + drawdownProjectionDate
				+ ", pclsWithdrawalPercentage=" + pclsWithdrawalPercentage
				+ ", alternativeRetirementAge=" + alternativeRetirementAge
				+ ", alternativePersonalPayment=" + alternativePersonalPayment
				+ ", alternativeEmployerPayment=" + alternativeEmployerPayment
				+ "]";
	}

   

}
