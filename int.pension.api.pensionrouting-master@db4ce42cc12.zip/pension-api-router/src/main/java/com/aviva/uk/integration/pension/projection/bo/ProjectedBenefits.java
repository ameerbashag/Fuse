/**
 *
 */
package com.aviva.uk.integration.pension.projection.bo;

import java.math.BigDecimal;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import org.codehaus.jackson.annotate.JsonProperty;
import org.codehaus.jackson.annotate.JsonPropertyOrder;
import org.codehaus.jackson.map.annotate.JsonSerialize;

/**
 * @author MA293081
 *
 */
@XmlRootElement(name = "projectedBenefit")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(propOrder = { "projectionBasis", "aweRate", "inflationRate", "nprGrowthRate", "prGrowthRate",
        "finalContributions", "projectedAnnuity", "incomeDrawdownGrowthRate"})
@JsonPropertyOrder({ "projectionBasis", "aweRate", "inflationRate", "nprGrowthRate", "prGrowthRate",
        "finalContributions", "projectedAnnuity", "incomeDrawdownGrowthRate" })
@JsonSerialize(include = JsonSerialize.Inclusion.NON_NULL)
public class ProjectedBenefits {
    @XmlElement(name = "projectionBasis")
    private Projection projectionBasis;
    @XmlElement(name = "finalContributions")
    private FinalContributions finalContributions;
    @XmlElement(name = "projectedAnnuity")
    private ProjectedAnnuity projectedAnnuity;
    @XmlElement(name = "averageWeeklyEarningsRate")
    @JsonProperty(value = "averageWeeklyEarningsRate")
    private BigDecimal aweRate;
    @XmlElement(name = "nonProtectedRightsGrowthRate")
    @JsonProperty(value = "nonProtectedRightsGrowthRate")
    private BigDecimal nprGrowthRate;    
    @XmlElement(name = "inflationRate")
    private BigDecimal inflationRate;
    @XmlElement(name = "protectedRightsGrowthRate")
    @JsonProperty(value = "protectedRightsGrowthRate")
    private BigDecimal prGrowthRate;
    @XmlElement(name = "incomeDrawdownGrowthRate")
    @JsonProperty(value = "incomeDrawdownGrowthRate")
    private BigDecimal incomeDrawdownGrowthRate;

    public FinalContributions getFinalContributions() {
        return finalContributions;
    }

    public void setFinalContributions(FinalContributions finalContributions) {
        this.finalContributions = finalContributions;
    }

    public ProjectedAnnuity getProjectedAnnuity() {
        return projectedAnnuity;
    }

    public void setProjectedAnnuity(ProjectedAnnuity projectedAnnuity) {
        this.projectedAnnuity = projectedAnnuity;
    }

    public BigDecimal getAweRate() {
        return aweRate;
    }

    public void setAweRate(BigDecimal aweRate) {
        this.aweRate = aweRate;
    }

    public BigDecimal getNprGrowthRate() {
        return nprGrowthRate;
    }

    public void setNprGrowthRate(BigDecimal nprGrowthRate) {
        this.nprGrowthRate = nprGrowthRate;
    }

    public BigDecimal getInflationRate() {
        return inflationRate;
    }

    public void setInflationRate(BigDecimal inflationRate) {
        this.inflationRate = inflationRate;
    }

    public BigDecimal getPrGrowthRate() {
        return prGrowthRate;
    }

    public void setPrGrowthRate(BigDecimal prGrowthRate) {
        this.prGrowthRate = prGrowthRate;
    }

    @Override
    public String toString() {
        return "ProjectedBenefits [projectionBasis=" + projectionBasis + ", finalContributions=" + finalContributions
                + ", projectedAnnuity=" + projectedAnnuity + ", aweRate=" + aweRate + ", nprGrowthRate="
                + nprGrowthRate + ", inflationRate=" + inflationRate + ", prGrowthRate=" + prGrowthRate + ", incomeDrawdownGrowthRate=" + incomeDrawdownGrowthRate + "]";
    }

    public Projection getProjectionBasis() {
        return projectionBasis;
    }

    public void setProjectionBasis(Projection projectionBasis) {
        this.projectionBasis = projectionBasis;
    }
    
    public BigDecimal getIncomeDrawdownGrowthRate() {
		return incomeDrawdownGrowthRate;
	}

	public void setIncomeDrawdownGrowthRate(BigDecimal incomeDrawdownGrowthRate) {
		this.incomeDrawdownGrowthRate = incomeDrawdownGrowthRate;
	}

}
