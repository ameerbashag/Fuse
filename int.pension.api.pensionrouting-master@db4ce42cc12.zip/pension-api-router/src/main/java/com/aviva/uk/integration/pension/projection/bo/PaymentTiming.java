
package com.aviva.uk.integration.pension.projection.bo;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;

import org.codehaus.jackson.annotate.JsonCreator;
import org.codehaus.jackson.annotate.JsonValue;

@XmlType(name = "PaymentTiming")
@XmlEnum
public enum PaymentTiming {

    @XmlEnumValue("Advance")
    ADVANCE("Advance"),
    @XmlEnumValue("Arrear")
    ARREAR("Arrear"),
    @XmlEnumValue("FirstOfMonth")
    FIRST_OF_MONTH("FirstOfMonth");
    private final String value;

    PaymentTiming(String v) {
        value = v;
    }
    
    @JsonValue
    public String value() {
        return value;
    }

    @JsonCreator    
    public static PaymentTiming fromValue(String v) {
        for (PaymentTiming c: PaymentTiming.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
