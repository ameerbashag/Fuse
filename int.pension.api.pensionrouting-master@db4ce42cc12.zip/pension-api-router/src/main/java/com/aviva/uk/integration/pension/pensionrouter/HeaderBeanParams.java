package com.aviva.uk.integration.pension.pensionrouter;

import javax.ws.rs.HeaderParam;

import org.hibernate.validator.constraints.NotBlank;

import com.aviva.uk.integration.validation.constraints.ViolationLoggingLevel;
import com.aviva.uk.integration.validation.constraints.ViolationLoggingLevel.LoggingLevel;

@ViolationLoggingLevel(loggingLevel = LoggingLevel.FLAT)
public class HeaderBeanParams {

    @HeaderParam(value = "Requesting-System")
    @NotBlank(message = "Requesting-System missing from header")
    private String requestingSystem;

}
