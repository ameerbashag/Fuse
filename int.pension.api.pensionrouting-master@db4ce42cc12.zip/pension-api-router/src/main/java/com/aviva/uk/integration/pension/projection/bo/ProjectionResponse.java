package com.aviva.uk.integration.pension.projection.bo;

import java.math.BigDecimal;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;
import org.codehaus.jackson.annotate.JsonProperty;
import org.codehaus.jackson.annotate.JsonPropertyOrder;
import org.codehaus.jackson.map.annotate.JsonSerialize;

@XmlRootElement(name = "pensionProjectionResponse")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(propOrder = { "planNumber", "prjRetirementDate", "employerPayment", "personalPayment",
        "projectionAssumptions", "guaranteeBasisYears", "spousesPensionPct", "minimumRetirementAge",
        "waiverOfContributionType", "lCDDate", "totalRegularPayment", "pIEDate","immediateAnnuity", "projectedBenefits", "projectedIncomeDrawdownFunds", "ageFundHitZero" })
@JsonPropertyOrder({ "planNumber", "prjRetirementDate", "employerPayment", "personalPayment", "projectionAssumptions",
        "guaranteeBasisYears", "spousesPensionPct", "minimumRetirementAge", "waiverOfContributionType", "lCDDate",
        "totalRegularPayment", "pIEDate","immediateAnnuity", "projectedBenefits", "projectedIncomeDrawdownFunds", "ageFundHitZero" })
@JsonSerialize(include = JsonSerialize.Inclusion.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class ProjectionResponse {

    
	private List<ProjectedBenefits> projectedBenefits;

    private String planNumber;

    @XmlElement(name = "projectionRetirementDate")
    @JsonProperty(value = "projectionRetirementDate")
    private String prjRetirementDate;
    
    @XmlElement(name = "employerPayment")
    @JsonProperty(value = "employerPayment")
    private CurrencyAmount employerPayment;

    @XmlElement(name = "personalPayment")
    @JsonProperty(value = "personalPayment")
    private CurrencyAmount personalPayment;

    @XmlElement(name = "projectionAssumptions")
    @JsonProperty(value = "projectionAssumptions")
    private ProjectionAssumptions projectionAssumptions;

    private Integer guaranteeBasisYears;

    @XmlElement(name = "spousesPensionPct")
    private BigDecimal spousesPensionPct;

    @XmlElement(name = "minimumRetirementAge")
    private Integer minimumRetirementAge;

    @XmlElement(name = "waiverOfContributionType")
    private String waiverOfContributionType;

    @XmlElement(name = "lastContributionDueDate")
    @JsonProperty(value = "lastContributionDueDate")
    private String lCDDate;

    @XmlElement(name = "paymentIncreaseEffectiveDate")
    @JsonProperty(value = "paymentIncreaseEffectiveDate")
    private String pIEDate;

    @XmlElement(name = "totalRegularPayment")
    @JsonProperty(value = "totalRegularPayment")
    private CurrencyAmount totalRegularPayment;
    
    @XmlElement(name = "immediateAnnuity")
	@JsonProperty(value = "immediateAnnuity")
	private ImmediateAnnuity immediateAnnuity;
    
    @XmlElement(name = "projectedIncomeDrawdownFunds")
	@JsonProperty(value = "projectedIncomeDrawdownFunds")
	private ProjectedIncomeDrawdownFunds projectedIncomeDrawdownFunds;    
    
    @XmlElement(name = "ageFundHitZero")
	@JsonProperty(value = "ageFundHitZero")
	private Integer ageFundHitZero ;

	public CurrencyAmount getEmployerPayment() {
        return employerPayment;
    }

    public void setEmployerPayment(CurrencyAmount employerPayment) {
        this.employerPayment = employerPayment;
    }

    public CurrencyAmount getPersonalPayment() {
        return personalPayment;
    }

    public void setPersonalPayment(CurrencyAmount personalPayment) {
        this.personalPayment = personalPayment;
    }

    public List<ProjectedBenefits> getProjectedBenefits() {
        return projectedBenefits;
    }

    public void setProjectedBenefits(List<ProjectedBenefits> projectedBenefits) {
        this.projectedBenefits = projectedBenefits;
    }

    public String getPlanNumber() {
        return planNumber;
    }

    public void setPlanNumber(String planNumber) {
        this.planNumber = planNumber;
    }

    public String getPrjRetirementDate() {
        return prjRetirementDate;
    }

    public void setPrjRetirementDate(String prjRetirementDate) {
        this.prjRetirementDate = prjRetirementDate;
    }

    public ProjectionAssumptions getProjectionAssumptions() {
        return projectionAssumptions;
    }

    public void setProjectionAssumptions(ProjectionAssumptions projectionAssumptions) {
        this.projectionAssumptions = projectionAssumptions;
    }

    public Integer getGuaranteeBasisYears() {
        return guaranteeBasisYears;
    }

    public void setGuaranteeBasisYears(Integer guaranteeBasisYears) {
        this.guaranteeBasisYears = guaranteeBasisYears;
    }

    public BigDecimal getSpousesPensionPct() {
        return spousesPensionPct;
    }

    public void setSpousesPensionPct(BigDecimal spousesPensionPct) {
        this.spousesPensionPct = spousesPensionPct;
    }

    public Integer getMinimumRetirementAge() {
        return minimumRetirementAge;
    }

    public void setMinimumRetirementAge(Integer minimumRetirementAge) {
        this.minimumRetirementAge = minimumRetirementAge;
    }

    public String getWaiverOfContributionType() {
        return waiverOfContributionType;
    }

    public void setWaiverOfContributionType(String waiverOfContributionType) {
        this.waiverOfContributionType = waiverOfContributionType;
    }

    public String getlCDDate() {
        return lCDDate;
    }

    public void setlCDDate(String lCDDate) {
        this.lCDDate = lCDDate;
    }

    public String getpIEDate() {
        return pIEDate;
    }

    public void setpIEDate(String pIEDate) {
        this.pIEDate = pIEDate;
    }

    public CurrencyAmount getTotalRegularPayment() {
        return totalRegularPayment;
    }

    public void setTotalRegularPayment(CurrencyAmount totalRegularPayment) {
        this.totalRegularPayment = totalRegularPayment;
    }
    
    public ImmediateAnnuity getImmediateAnnuity() {
		return immediateAnnuity;
	}

	public void setImmediateAnnuity(ImmediateAnnuity immediateAnnuity) {
		this.immediateAnnuity = immediateAnnuity;
	}

    public ProjectedIncomeDrawdownFunds getProjectedIncomeDrawdownFunds() {
		return projectedIncomeDrawdownFunds;
	}

	public void setProjectedIncomeDrawdownFunds(ProjectedIncomeDrawdownFunds projectedIncomeDrawdownFunds) {
		this.projectedIncomeDrawdownFunds = projectedIncomeDrawdownFunds;
	}
	
	public Integer getAgeFundHitZero() {
		return ageFundHitZero;
	}

	public void setAgeFundHitZero(Integer ageFundHitZero) {
		this.ageFundHitZero = ageFundHitZero;
	}
}