package com.aviva.uk.integration.pension.projection.bo;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;
import org.codehaus.jackson.annotate.JsonPropertyOrder;
import org.codehaus.jackson.map.annotate.JsonSerialize;

@XmlRootElement(name = "immediateAnnuity")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(propOrder = { "incomeDrawdown", "accumulation" })
@JsonPropertyOrder({ "incomeDrawdown", "accumulation" })
@JsonSerialize(include = JsonSerialize.Inclusion.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class ImmediateAnnuity {

	@XmlElement(name = "incomeDrawdown")
	private CurrencyAmount incomeDrawdown;
	@XmlElement(name = "accumulation")
	private CurrencyAmount accumulation;

	public CurrencyAmount getIncomeDrawdown() {
		return incomeDrawdown;
	}

	public void setIncomeDrawdown(CurrencyAmount incomeDrawdown) {
		this.incomeDrawdown = incomeDrawdown;
	}

	public CurrencyAmount getAccumulation() {
		return accumulation;
	}

	public void setAccumulation(CurrencyAmount accumulation) {
		this.accumulation = accumulation;
	}
	
	@Override
	public String toString() {
		return "ClassPojo [incomeDrawdown = " + incomeDrawdown + ", accumulation = "
				+ accumulation + "]";
	}
}
