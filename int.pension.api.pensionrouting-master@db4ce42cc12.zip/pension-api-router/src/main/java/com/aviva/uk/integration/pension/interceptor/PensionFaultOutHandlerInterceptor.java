/*
 * Copyright (c) 2015 AVIVA.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of AVIVA
 * ("Confidential Information").  
 * You shall not disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with AVIVA.
 */
package com.aviva.uk.integration.pension.interceptor;

import java.util.List;

import javax.ws.rs.core.Response;

import org.apache.cxf.interceptor.Fault;
import org.apache.cxf.interceptor.LoggingOutInterceptor;
import org.apache.cxf.jaxrs.interceptor.JAXRSOutInterceptor;
import org.apache.cxf.message.Message;
import org.apache.cxf.message.MessageContentsList;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;

import com.aviva.uk.integration.errorhandling.ProblemDetails;
import com.aviva.uk.integration.logging.MDCConstants;

/**
 * PensionFaultOutHandlerInterceptor is called when a Fault is thrown by Interceptors so as to create a JSON type
 * response
 * 
 * @author APPUR
 *
 */
public class PensionFaultOutHandlerInterceptor extends JAXRSOutInterceptor {

    private final static Logger LOG = LoggerFactory.getLogger(PensionFaultOutHandlerInterceptor.class);
    private final String TITLE = "Request Validation Failure";
    private final String INSTANCE = "pensionPlans/error/";
    private final String PLANNUMBER_MISSING = "PlanNumber missing";
    private final String MALFORMED_SUBRESOURCE = "Sub-Resource is not recognised";
    private final String REQUEST_MALFORMED = "Request Malformed, missing plan number";

    /**
     * Constructor adds this Interceptor to be called before the LoggingOutInterceptor
     */
    public PensionFaultOutHandlerInterceptor() {

        getBefore().add(LoggingOutInterceptor.class.getName());
    }

    /**
     * Overrides the JAXRSOutInterceptor handleMessage to create a JSON response for consumer
     */
    @Override
    public void handleMessage(Message message) {

        LOG.info(">>>> Entered PensionFaultOutHandlerInterceptor");

        Exception ex = message.getContent(Exception.class);

        if (ex == null) {
            throw new RuntimeException("Exception is expected");
        }
        if (!(ex instanceof Fault)) {
            LOG.error(">>>> Exception occured, but Fault was expected ");
            throw new RuntimeException("Fault is expected");
        }
        switch (ex.getMessage()) {
        case PLANNUMBER_MISSING:
            throwException(message, 400, TITLE, "Parameter planNumber is required");
            break;
        case MALFORMED_SUBRESOURCE:
            throwException(message, 400, TITLE, "Sub-Resource is not recognised");
            break;
        case REQUEST_MALFORMED:
            throwException(message, 400, "Bad Request", "Request Malformed, missing plan number");
            break;
        default:
            LOG.info(">>>> Error found, but not recognised, exiting PensionFaultOutHandlerInterceptor");
        }

        LOG.info(">>>> Exiting PensionFaultOutHandlerInterceptor");
    }

    public void throwException(Message message, int status, String title, String detail) {

        ProblemDetails pd = new ProblemDetails();
        String correlationid = MDC.get(MDCConstants.ESB_GUID);

        pd.setDetail(detail);
        pd.setInstance(INSTANCE + correlationid);
        pd.setTitle(title);
        pd.setStatus(status);

        Response response = Response.status(status).type("application/json").entity(pd).build();

        message.setContent(List.class, new MessageContentsList(response));

        super.handleMessage(message);

        message.getInterceptorChain().abort();

    }
}
