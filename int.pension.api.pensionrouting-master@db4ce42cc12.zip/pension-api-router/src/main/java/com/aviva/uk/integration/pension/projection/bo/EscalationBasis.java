
package com.aviva.uk.integration.pension.projection.bo;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;

import org.codehaus.jackson.annotate.JsonCreator;
import org.codehaus.jackson.annotate.JsonValue;

@XmlType(name = "EscalationBasis")
@XmlEnum
public enum EscalationBasis {

    @XmlEnumValue("None")
    NONE("None"),
    @XmlEnumValue("FixedEsc")
    FIXED_ESC("FixedEsc"),
    @XmlEnumValue("LPIEsc")
    LPI_ESC("LPIEsc"),
    @XmlEnumValue("RPIEsc")
    RPI_ESC("RPIEsc");
    private final String value;

    EscalationBasis(String v) {
        value = v;
    }

    @JsonValue
    public String value() {
        return value;
    }
    
    @JsonCreator
    public static EscalationBasis fromValue(String v) {
        for (EscalationBasis c: EscalationBasis.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
