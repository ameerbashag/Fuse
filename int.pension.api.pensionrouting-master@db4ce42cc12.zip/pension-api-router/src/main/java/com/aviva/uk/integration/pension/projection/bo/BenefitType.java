package com.aviva.uk.integration.pension.projection.bo;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;

import org.codehaus.jackson.annotate.JsonCreator;
import org.codehaus.jackson.annotate.JsonValue;

@XmlType(name = "BenefitType")
@XmlEnum
public enum BenefitType {

    @XmlEnumValue("SingleLife")
    SINGLE_LIFE("SingleLife"), @XmlEnumValue("SLPlusReversionary")
    SL_PLUS_REVERSIONARY("SLPlusReversionary"), @XmlEnumValue("LongestLifeLevel")
    LONGEST_LIFE_LEVEL("LongestLifeLevel"), @XmlEnumValue("JointMemberDeath")
    JOINT_MEMBER_DEATH("JointMemberDeath");
    private final String value;

    BenefitType(String v) {
        value = v;
    }

    @JsonValue
    public String value() {
        return value;
    }

    @JsonCreator
    public static BenefitType fromValue(String v) {
        for (BenefitType c : BenefitType.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
