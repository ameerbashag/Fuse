/*
 * Copyright (c) 2015 AVIVA.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of AVIVA
 * ("Confidential Information").  
 * You shall not disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with AVIVA.
 */
package com.aviva.uk.integration.pension.interceptor;

import org.apache.cxf.Bus;
import org.apache.cxf.feature.AbstractFeature;
import org.apache.cxf.interceptor.InterceptorProvider;

/**
 * PensionInterceptorFilter Class that initialize's and adds the custom interceptors to respective Interceptor Chains
 * eg: Inbound or Outbound or Fault
 * 
 * @author APPUR
 */

public class PensionInterceptorFilter extends AbstractFeature {

    protected static final PensionInInterceptor IN = new PensionInInterceptor();
    protected static final PensionFaultOutHandlerInterceptor OUT = new PensionFaultOutHandlerInterceptor();

    /**
     * Initializes the custom Interceptors to it's specific Interceptor Chains
     * 
     * @param provider {@link InterceptorProvider} returns the various available interceptor chains
     * @param bus {@link Bus}
     */
    @Override
    protected void initializeProvider(InterceptorProvider provider, Bus bus) {

        provider.getInInterceptors().add(IN);
        provider.getOutFaultInterceptors().add(OUT);

    }
}
