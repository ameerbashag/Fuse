package com.aviva.uk.integration.pension.projection.bo;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;

import org.codehaus.jackson.annotate.JsonCreator;
import org.codehaus.jackson.annotate.JsonValue;

@XmlType(name = "QuotationType")
@XmlEnum
public enum QuotationType {

    @XmlEnumValue("EstimatedMaturityValue")
    ESTIMATED_MATURITY_VALUE("EstimatedMaturityValue"),
    @XmlEnumValue("MaturityQuote")
    MATURITY_QUOTE("MaturityQuote"),
    @XmlEnumValue("ChangeOfCharge")
    CHANGE_OF_CHARGE("ChangeOfCharge"),
    @XmlEnumValue("YearlyStatement")
    YEARLY_STATEMENT("YearlyStatement");
    private final String value;

    QuotationType(String v) {
        value = v;
    }

    @JsonValue
    public String value() {
        return value;
    }
    
    @JsonCreator
    public static QuotationType fromValue(String v) {
        for (QuotationType c: QuotationType.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
