package com.aviva.uk.integration.pension.pensionrouter;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.camel.Exchange;
import org.apache.camel.component.cxf.common.message.CxfConstants;
import org.apache.cxf.interceptor.Fault;

import com.aviva.uk.integration.errorhandling.ProblemDetailsException;

public class PensionRouterUtil {

    public String getTarget(Exchange exchange) throws ProblemDetailsException {

        String uri = (String) exchange.getIn().getHeader(Exchange.HTTP_URI);
        String operationName = (String) exchange.getIn().getHeader(CxfConstants.OPERATION_NAME);
        String request = uri.substring(uri.lastIndexOf("pensionPlans"));
        Pattern subResourceRequest = Pattern.compile("pensionPlans\\/.+\\/.+");
        Matcher m = subResourceRequest.matcher(request);
        String resource = uri.substring(uri.lastIndexOf("/") + 1);
        String targetAddress = PensionRouterConstant.routingTable.get(operationName);
        if (m.matches()) {
            if (null == targetAddress) {
                Fault fault = new Fault(new Exception("Sub-Resource " + resource + " was not recognised"));
                fault.setStatusCode(400);
                throw fault;
            }
        }

        return targetAddress;

    }

}
