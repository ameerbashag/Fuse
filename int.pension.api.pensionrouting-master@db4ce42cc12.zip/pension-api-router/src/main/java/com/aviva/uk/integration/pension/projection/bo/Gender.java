package com.aviva.uk.integration.pension.projection.bo;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;

import org.codehaus.jackson.annotate.JsonCreator;
import org.codehaus.jackson.annotate.JsonValue;

@XmlType(name = "Gender")
@XmlEnum
public enum Gender {

    @XmlEnumValue("Male")
    MALE("Male"), @XmlEnumValue("Female")
    FEMALE("Female");
    private final String value;

    Gender(String v) {
        value = v;
    }

    @JsonValue
    public String value() {
        return value;
    }

    @JsonCreator
    public static Gender fromValue(String v) {
        for (Gender c : Gender.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
