
package com.aviva.uk.integration.pension.projection.bo;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;

import org.codehaus.jackson.annotate.JsonCreator;
import org.codehaus.jackson.annotate.JsonValue;

@XmlType(name = "Projection")
@XmlEnum(String.class)
public enum Projection {

    @XmlEnumValue("Low")
    LOW("Low"),
    @XmlEnumValue("Mid")
    MID("Mid"),
    @XmlEnumValue("High")
    HIGH("High");
    private final String value;

    Projection(String v) {
        value = v;
    }

    @JsonValue    
    public String value() {
        return value;
    }

    @JsonCreator    
    public static Projection fromValue(String v) {
        for (Projection c: Projection.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
