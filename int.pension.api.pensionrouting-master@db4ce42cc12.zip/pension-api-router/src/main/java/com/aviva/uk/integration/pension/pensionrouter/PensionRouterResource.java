package com.aviva.uk.integration.pension.pensionrouter;

import com.aviva.uk.integration.pension.projection.bo.ProjectionRequest;
import com.aviva.uk.integration.pension.response.bo.roles.PensionRoles;

import java.util.List;

import javax.annotation.security.RolesAllowed;
import javax.ws.rs.BeanParam;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;

import org.apache.camel.Body;

public class PensionRouterResource {

    @RolesAllowed({ "UK_GPPPensionPolicyHolderRole", "PensionProjectionDataRead" })
    @GET
    @Path("{planNumber}/valuationSummaries")
    @Produces({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON, "application/problem+json" })
    @Consumes({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON, "application/problem+json" })
    public Object getValuationSummary(@PathParam("planNumber") String planNumber) {
        return null;
    }

    @RolesAllowed({ "ROL_ProjectionDataSummary", "PensionProjectionDataRead" })
    @GET
    @Path("{planNumber}/projectionDataSummary")
    @Produces({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON, "application/problem+json" })
    // @Produces({"application/xml", "application/json"})
    @Consumes({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON, "application/problem+json" })
    public Object getProjectionDataSummary(@PathParam("planNumber") String planNumber) {
        return null;
    }

    @RolesAllowed("CurrentPerformance")
    @GET
    @Path("/{planNumber}/currentPerformance")
    @Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
    @Consumes({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
    public Object currentPerformance(@PathParam("planNumber") String planNumber, @BeanParam HeaderBeanParams request) {
        return null;
    }

    @RolesAllowed("Pension_PensionProducts_Read")
    @GET
    @Path("/{planNumber}/pensionProducts")
    @Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
    @Consumes({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
    public Object pensionProducts(@PathParam("planNumber") String planNumber, @BeanParam HeaderBeanParams request) {
        return null;
    }

    @RolesAllowed("Pension_Planholders_Read")
    @GET
    @Path("/{planNumber}/planholders")
    @Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
    @Consumes({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
    public Object planholders(@PathParam("planNumber") String planNumber) {
        return null;
    }

    @RolesAllowed("Pension_PensionPlans_Read")
    @GET
    @Path("/{planNumber}")
    @Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
    @Consumes({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
    public Object pensionPlan(@PathParam("planNumber") String planNumber, @BeanParam HeaderBeanParams request) {
        return null;
    }

    @RolesAllowed({ "Pension_Funds_Read" })
    @GET
    @Path("{planNumber}/funds")
    @Produces({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON, "application/problem+json" })
    @Consumes({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON, "application/problem+json" })
    public Object getFunds(@PathParam("planNumber") String planNumber) {
        return null;
    }

    @RolesAllowed("Pension_FundChoices_Read")
    @GET
    @Produces({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON, "application/problem+json" })
    @Consumes({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON, "application/problem+json" })
    @Path("/{planNumber}/fundChoices")
    public String getFundChoicesResource(@PathParam("planNumber") String planNumber) {
        return null;
    }

    @RolesAllowed("Pension_FundHoldings_Read")
    @GET
    @Path("{planNumber}/fundHoldings")
    @Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML, "application/problem+json" })
    @Consumes({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML, "application/problem+json" })
    public Object getFundHoldings(@PathParam("planNumber") String planNumber, @BeanParam HeaderBeanParams request) {
        return null;
    }

    @RolesAllowed({ "Pension_MonetaryTransactions_Read" })
    @GET
    @Path("{planNumber}/monetaryTransactions")
    @Produces({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON, "application/problem+json" })
    @Consumes({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON, "application/problem+json" })
    public Object getMonetaryTransactions(@PathParam("planNumber") String planNumber,
            @BeanParam HeaderBeanParams request) {
        return null;
    }

    @RolesAllowed({ "Pension_MonetaryTransactionSummaries" })
    @GET
    @Path("/{planNumber}/monetaryTransactionSummaries")
    @Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML, MediaType.TEXT_XML, "application/problem+json" })
    @Consumes({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON, "application/problem+json" })
    public Object monetartyTransactionSummaries(@PathParam("planNumber") String planNumber,
            @BeanParam HeaderBeanParams request) {
        // this does nothing -- just a shell for CXF and Camel

        return null;
    }

    @RolesAllowed({ "Pension_MonetaryTransactionTotals_Read" })
    @GET
    @Path("/{planNumber}/monetaryTransactionTotals")
    @Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML, "application/problem+json" })
    @Consumes({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML, "application/problem+json" })
    public Object monetaryTransactionTotals(@PathParam("planNumber") String planNumber,
            @BeanParam HeaderBeanParams request) {
        // this does nothing -- just a shell for CXF and Camel
        return null;
    }

    @RolesAllowed({ "Pension_RegularContributionInstructions_Read" })
    @GET
    @Path("{planNumber}/regularContributionInstructions")
    @Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML, "application/problem+json" })
    @Consumes({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
    public Object getRegularContributionInstructions(@PathParam("planNumber") String planNumber,
            @BeanParam HeaderBeanParams request) {
        return null;
    }

    @RolesAllowed({ "Pension_InvestmentStrategy_Read" })
    @GET
    @Path("{planNumber}/investmentStrategies")
    @Produces({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON, "application/problem+json" })
    @Consumes({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON, "application/problem+json" })
    public Object getRegularInvestmentStrategies(@PathParam("planNumber") String planNumber,
            @BeanParam HeaderBeanParams request) {
        return null;
    }

    @RolesAllowed({ "Pension_LatestContributions_Read" })
    @GET
    @Path("{planNumber}/latestContributions")
    @Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML, "application/problem+json" })
    @Consumes({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML, "application/problem+json" })
    public Object getLatestContributions(@PathParam("planNumber") String planNumber, @BeanParam HeaderBeanParams request) {
        return null;
    }

    @RolesAllowed({ "Pension_NextContributions_Read" })
    @GET
    @Path("{planNumber}/nextContributions")
    @Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML, "application/problem+json" })
    @Consumes({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML, "application/problem+json" })
    public Object getNextContributions(@PathParam("planNumber") String planNumber, @BeanParam HeaderBeanParams request) {
        return null;
    }

    @RolesAllowed({ "Pension_LifeCoverInst_Read" })
    @GET
    @Path("{planNumber}/lifeCoverInstructions")
    @Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML, MediaType.TEXT_XML, "application/problem+json" })
    @Consumes({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON, "application/problem+json" })
    public Object getLifeCoverInstructions(@PathParam("planNumber") String planNumber,
            @BeanParam HeaderBeanParams request) {
        return null;
    }

    @RolesAllowed({ "Pension_LoyaltyBonuses_Read" })
    @GET
    @Path("{planNumber}/loyaltyBonuses")
    @Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML, MediaType.TEXT_XML, "application/problem+json" })
    @Consumes({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON, "application/problem+json" })
    public Object getLoyaltyBonuses(@PathParam("planNumber") String planNumber) {
        return null;
    }

    @RolesAllowed({ "Pension_Valuations_Read" })
    @GET
    @Path("{planNumber}/valuations")
    @Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML, MediaType.TEXT_XML, "application/problem+json" })
    @Consumes({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON, "application/problem+json" })
    public Object getValuations(@PathParam("planNumber") String planNumber, @BeanParam HeaderBeanParams request) {
        return null;
    }

    @RolesAllowed({ "Pension_ConventionalValuations_Read" })
    @GET
    @Path("{planNumber}/conventionalValuations")
    @Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML, MediaType.TEXT_XML, "application/problem+json" })
    @Consumes({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON, "application/problem+json" })
    public Object getConventionalValuations(@PathParam("planNumber") String planNumber,
            @BeanParam HeaderBeanParams request) {
        return null;
    }

    @RolesAllowed("Pension_GroupPensionSummaries_Read")
    @GET
    @Path("{planNumber}/groupPensionSummaries")
    @Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML, MediaType.TEXT_XML, "application/problem+json" })
    @Consumes({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON, "application/problem+json" })
    public String getGroupPensionSummaries(@PathParam("planNumber") String planNumber,
            @BeanParam HeaderBeanParams request) {
        return null;
    }

    @RolesAllowed("pension-read")
    @GET
    @Path("{planNumber}/projectionData")
    @Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML, "application/problem+json" })
    @Consumes({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
    public Object getPensionProjectionData(@PathParam("planNumber") String request,
            @QueryParam("effectiveDate") String effectiveDate) {
        return null;
    }

    @RolesAllowed("pension-write")
    @POST
    @Path("{planNumber}/projection")
    @Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML, "application/problem+json" })
    @Consumes({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML, "application/problem+json" })
    public Object getPensionProjection(@PathParam("planNumber") String planNumber, @Body ProjectionRequest request) {
        return null;
    }

    @RolesAllowed({ "Pension_Valuations_Read" })
    @GET
    @Path("{planNumber}/ipfunddetails")
    @Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML, MediaType.TEXT_XML, "application/problem+json" })
    @Consumes({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON, "application/problem+json" })
    public Object getIpFundDetails(@PathParam("planNumber") String planNumber) {
        return null;
    }

    @RolesAllowed({ "Pension_Roles_Read" })
    @GET
    @Path("{planNumber}/roles")
    @Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML, MediaType.TEXT_XML, "application/problem+json" })
    @Consumes({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON, "application/problem+json" })
    public Object getPensionRoles(@PathParam("planNumber") String planNumber,
            @QueryParam("roleType") List<String> roleTypes) {
        return null;
    }

    @RolesAllowed({ "Pension_Roles_Write" })
    @POST
    @Path("{planNumber}/roles")
    @Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML, MediaType.TEXT_XML, "application/problem+json" })
    @Consumes({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON, "application/problem+json" })
    public Object addPensionRoles(@PathParam("planNumber") String planNumber, @Body PensionRoles roles) {
        return null;
    }

    @RolesAllowed({ "Pension_Roles_Write" })
    @POST
    @Path("{planNumber}/roles/end")
    @Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML, MediaType.TEXT_XML, "application/problem+json" })
    @Consumes({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML, "application/problem+json" })
    public Object endPensionRoles(@PathParam("planNumber") String planNumber, @Body PensionRoles roles) {
        return null;
    }

    @RolesAllowed({ "Pension_Charges_Read" })
    @GET
    @Path("{planNumber}/charges")
    @Produces({ MediaType.APPLICATION_JSON, "application/problem+json" })
    public Object getPensionCharges(@PathParam("planNumber") String planNumber) {
        return null;
    }

    @RolesAllowed({ "Pension_BankDetails_Read" })
    @GET
    @Path("{planNumber}/bankDetails")
    @Produces({ MediaType.APPLICATION_JSON, "application/problem+json" })
    @Consumes({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML, "application/problem+json" })
    public Object getBankDetails(@PathParam("planNumber") String planNumber, @BeanParam HeaderBeanParams request) {
        return null;
    }
}
