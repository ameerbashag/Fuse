package com.aviva.uk.integration.pension.projection.bo;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;

import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.lang.StringUtils;
import org.codehaus.jackson.annotate.JsonCreator;
import org.codehaus.jackson.annotate.JsonValue;

@XmlType(name = "PaymentFrequency")
@XmlEnum
public enum PaymentFrequency {

    @XmlEnumValue("Weekly")
    WEEKLY("Weekly", "Weekly", "Weekly"),

    @XmlEnumValue("Fortnightly")
    FORTNIGHTLY("2-Weekly", null, "Fortnightly"),

    @XmlEnumValue("FourWeekly")
    FOUR_WEEKLY("4-Weekly", null, "FourWeekly"),

    @XmlEnumValue("Monthly")
    MONTHLY("Monthly"),

    @XmlEnumValue("Quarterly")
    QUARTERLY("Quarterly"),

    @XmlEnumValue("HalfYearly")
    HALF_YEARLY("HalfYearly", "Half-Yearly", null, "HalfYearly"),

    @XmlEnumValue("Yearly")
    YEARLY("Yearly", "Annual", "Yearly", "Yearly");

    private static final String[] IGNORED = { "single" };

    private final String projectionRequestValue;
    private final String bancsResponseValue;
    private final String unisureResponseValue;
    private final String projectionResponseValue;

    PaymentFrequency(String value) {
        this(value, value, value, value);
    }

    PaymentFrequency(String bancsResponseValue, String unisureResponseValue, String projectionResponseValue) {
        this(null, bancsResponseValue, unisureResponseValue, projectionResponseValue);
    }

    PaymentFrequency(String projectionRequestValue, String bancsResponseValue, String unisureResponseValue,
            String projectionResponseValue) {
        this.projectionRequestValue = projectionRequestValue;
        this.bancsResponseValue = bancsResponseValue;
        this.unisureResponseValue = unisureResponseValue;
        this.projectionResponseValue = projectionResponseValue;
    }

    @JsonValue
    public String value() {
        return projectionResponseValue;
    }

    @JsonCreator
    public static PaymentFrequency fromProjectionRequest(String projectionRequest) {
        for (PaymentFrequency paymentFrequency : values()) {
            if (StringUtils.equals(paymentFrequency.projectionRequestValue, projectionRequest)) {
                return paymentFrequency;
            }
        }

        throw new IllegalArgumentException(projectionRequest);
    }

    public static PaymentFrequency fromBancsResponse(String bancsResponse) {
        if (isIgnored(bancsResponse)) {
            return null;
        }

        for (PaymentFrequency paymentFrequency : values()) {
            if (paymentFrequency.bancsResponseValue.equals(bancsResponse)) {
                return paymentFrequency;
            }
        }
        throw new IllegalArgumentException(bancsResponse);
    }

    public static PaymentFrequency fromUnisureResponse(String unisureResponse) {
        if (isIgnored(unisureResponse)) {
            return null;
        }

        for (PaymentFrequency paymentFrequency : values()) {
            if (StringUtils.equals(paymentFrequency.unisureResponseValue, unisureResponse)) {
                return paymentFrequency;
            }
        }
        throw new IllegalArgumentException(unisureResponse);
    }

    private static boolean isIgnored(String value) {
        return ArrayUtils.contains(IGNORED, value.toLowerCase());
    }
}
