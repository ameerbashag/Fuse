package com.aviva.uk.integration.pension.projection.bo;

import java.math.BigDecimal;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import org.codehaus.jackson.annotate.JsonPropertyOrder;
import org.codehaus.jackson.map.annotate.JsonSerialize;

@XmlRootElement(name = "projectedAnnuity")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(propOrder = { "interestRate", "retailPricesIndexRate", "pension", "spousePension", "reducedPension",
        "taxFreeCash", "nonProtectedRightsFund", "protectedRightsFund" ,"IncomeDrawdownFund" })
@JsonPropertyOrder({ "interestRate", "retailPricesIndexRate", "pension", "spousePension", "reducedPension",
        "taxFreeCash", "nonProtectedRightsFund", "protectedRightsFund" ,"IncomeDrawdownFund" })
@JsonSerialize(include = JsonSerialize.Inclusion.NON_NULL)
public class ProjectedAnnuity {
    @XmlElement(name = "spousePension")
    private CurrencyAmount spousePension;
    @XmlElement(name = "interestRate")
    private BigDecimal interestRate;
    @XmlElement(name = "pension")
    private CurrencyAmount pension;
    @XmlElement(name = "taxFreeCash")
    private CurrencyAmount taxFreeCash;
    @XmlElement(name = "reducedPension")
    private CurrencyAmount reducedPension;
    @XmlElement(name = "nonProtectedRightsFund")
    private CurrencyAmount nonProtectedRightsFund;
    @XmlElement(name = "protectedRightsFund")
    private CurrencyAmount protectedRightsFund;
    @XmlElement(name = "retailPricesIndexRate")
    private BigDecimal retailPricesIndexRate;
    @XmlElement(name = "IncomeDrawdownFund")
    private CurrencyAmount incomeDrawdownFund;
    
    public CurrencyAmount getIncomeDrawdownFund() {
		return incomeDrawdownFund;
	}

	public void setIncomeDrawdownFund(CurrencyAmount incomeDrawdownFund) {
		this.incomeDrawdownFund = incomeDrawdownFund;
	}

    public CurrencyAmount getSpousePension() {
        return spousePension;
    }

    public void setSpousePension(CurrencyAmount spousePension) {
        this.spousePension = spousePension;
    }

    public CurrencyAmount getPension() {
        return pension;
    }

    public void setPension(CurrencyAmount pension) {
        this.pension = pension;
    }

    public CurrencyAmount getTaxFreeCash() {
        return taxFreeCash;
    }

    public void setTaxFreeCash(CurrencyAmount taxFreeCash) {
        this.taxFreeCash = taxFreeCash;
    }

    public CurrencyAmount getReducedPension() {
        return reducedPension;
    }

    public void setReducedPension(CurrencyAmount reducedPension) {
        this.reducedPension = reducedPension;
    }

    public CurrencyAmount getNonProtectedRightsFund() {
        return nonProtectedRightsFund;
    }

    public void setNonProtectedRightsFund(CurrencyAmount nonProtectedRightsFund) {
        this.nonProtectedRightsFund = nonProtectedRightsFund;
    }

    public CurrencyAmount getProtectedRightsFund() {
        return protectedRightsFund;
    }

    public void setProtectedRightsFund(CurrencyAmount protectedRightsFund) {
        this.protectedRightsFund = protectedRightsFund;
    }

    public BigDecimal getRetailPricesIndexRate() {
        return retailPricesIndexRate;
    }

    public void setRetailPricesIndexRate(BigDecimal retailPricesIndexRate) {
        this.retailPricesIndexRate = retailPricesIndexRate;
    }

    @Override
    public String toString() {
        return "ProjectedAnnuity [spousePension=" + spousePension + ", interestRate=" + interestRate + ", pension="
                + pension + ", taxFreeCash=" + taxFreeCash + ", reducedPension=" + reducedPension
                + ", nonProtectedRightsFund=" + nonProtectedRightsFund + ", protectedRightsFund=" + protectedRightsFund
                + ", retailPricesIndexRate=" + retailPricesIndexRate + "]";
    }

    public BigDecimal getInterestRate() {
        return interestRate;
    }

    public void setInterestRate(BigDecimal interestRate) {
        this.interestRate = interestRate;
    }

}
