package com.aviva.uk.integration.pension.projection.bo;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import org.codehaus.jackson.annotate.JsonPropertyOrder;
import org.codehaus.jackson.map.annotate.JsonSerialize;

@XmlRootElement(name = "finalContributions")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(propOrder = { "employee", "employer", "selfEmployed", "thirdParty", "employeeAVC" })
@JsonPropertyOrder({ "employee", "employer", "selfEmployed", "thirdParty", "employeeAVC" })
@JsonSerialize(include = JsonSerialize.Inclusion.NON_NULL)
public class FinalContributions {

    @XmlElement(name = "thirdParty")
    private CurrencyAmount thirdParty;
    @XmlElement(name = "employer")
    private CurrencyAmount employer;
    @XmlElement(name = "selfEmployed")
    private CurrencyAmount selfEmployed;
    @XmlElement(name = "employee")
    private CurrencyAmount employee;
    @XmlElement(name = "employeeAVC")
    private CurrencyAmount employeeAVC;

    public CurrencyAmount getThirdParty() {
        return thirdParty;
    }

    public void setThirdParty(CurrencyAmount thirdParty) {
        this.thirdParty = thirdParty;
    }

    public CurrencyAmount getEmployer() {
        return employer;
    }

    public void setEmployer(CurrencyAmount employer) {
        this.employer = employer;
    }

    public CurrencyAmount getSelfEmployed() {
        return selfEmployed;
    }

    public void setSelfEmployed(CurrencyAmount selfEmployed) {
        this.selfEmployed = selfEmployed;
    }

    public CurrencyAmount getEmployee() {
        return employee;
    }

    public void setEmployee(CurrencyAmount employee) {
        this.employee = employee;
    }

    public CurrencyAmount getEmployeeAVC() {
        return employeeAVC;
    }

    public void setEmployeeAVC(CurrencyAmount employeeAVC) {
        this.employeeAVC = employeeAVC;
    }

    @Override
    public String toString() {
        return "ClassPojo [thirdParty = " + thirdParty + ", employer = " + employer + ", selfEmployed = "
                + selfEmployed + ", employee = " + employee + "]";
    }
}
