/*
 * Copyright (c) 2015 AVIVA.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of AVIVA
 * ("Confidential Information").  
 * You shall not disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with AVIVA.
 */
package com.aviva.uk.integration.pension.router.component;

import static org.junit.Assert.assertEquals;

import java.io.IOException;

import org.apache.camel.test.spring.CamelSpringJUnit4ClassRunner;
import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.annotation.DirtiesContext.ClassMode;
import org.springframework.test.context.ContextConfiguration;

import com.aviva.uk.integration.test.HTTPUtils;

@RunWith(CamelSpringJUnit4ClassRunner.class)
@DirtiesContext(classMode = ClassMode.AFTER_EACH_TEST_METHOD)
@ContextConfiguration(locations = { "classpath:/META-INF/spring/camel-config.xml" })
/**
 * This class Test for missing plan number in request
 * 
 * @author renusea, salianl
 *
 */
public class MissingPlanNumberTest {

    static String inputPath = null;

    @BeforeClass
    public static void beforeClass() throws Exception {
        // These tests do NOT require authentication, since they validate the functionality of the In interceptor, which
        // is done before authorisation.
        final int inputPort = HTTPUtils.getAvailablePort();
        final String inputPath = "http://localhost:" + inputPort + "/api/v1/pensionPlans/";
        System.setProperty("inboundAddress", inputPath);
        MissingPlanNumberTest.inputPath = inputPath;
    }

    /**
     * Testing Missing planNumber scenario
     * 
     * @throws ClientProtocolException
     * @throws IOException
     */
    @Test
    public void testMissingPlanNumber() throws ClientProtocolException, IOException {
        final DefaultHttpClient httpclient = new DefaultHttpClient();

        final HttpGet httpGet = new HttpGet(inputPath);

        final HttpResponse response = httpclient.execute(httpGet);
        assertEquals(400, response.getStatusLine().getStatusCode());
    }

}
