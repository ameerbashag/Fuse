package com.aviva.uk.integration.pension.router.component;

import java.util.Dictionary;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.Properties;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.aviva.uk.integration.security.SecurityRepositoryConfig;
import com.aviva.uk.integration.security.UserCacheEntry;
import com.aviva.uk.integration.security.memory.InMemorySecurityRepository;
import com.aviva.uk.integration.test.HTTPUtils;

/**
 * SetUpRolesAndUsers is helper class for setting the roles and users required during the component test for contained
 * API's
 *
 * @author renusea,salianl
 *
 */
public class SetUpRolesAndUsers {

    private static Logger log = LoggerFactory.getLogger(SetUpRolesAndUsers.class);

    /**
     * Setting inputPath to test 401 & 403 error scenario
     *
     * @return A inputPath as {@link String}
     * @throws Exception
     */
    public static String initialize() throws Exception {

        final int inputPort = HTTPUtils.getAvailablePort();
        log.debug("inbound port will be: " + inputPort);
        final String inputPath = "http://localhost:" + inputPort + "/api/v1/pensionPlans/";
        System.setProperty("inboundAddress", inputPath);
        // Set jaas-realm config
        final Properties props = System.getProperties();
        props.setProperty("java.security.auth.login.config", "src/test/resources/jaas.cfg");

        // Setup User Cache Entry
        final SecurityRepositoryConfig config = SecurityRepositoryConfig.getConfig();
        final Dictionary<String, String> properties = new Hashtable<String, String>();
        properties.put(SecurityRepositoryConfig.CACHE_PERIOD, "-1");
        properties.put(SecurityRepositoryConfig.REPOSITORY_TYPE, "memory");

        config.updated(properties);

        try {
            final InMemorySecurityRepository repository = InMemorySecurityRepository.getInstance();

            final Set<String> allRoles = new HashSet<String>();
            allRoles.add("pension-read");
            allRoles.add("CurrentPerformance");
            allRoles.add("UK_GPPPensionPolicyHolderRole");
            allRoles.add("PensionProjectionDataRead");
            allRoles.add("ROL_ProjectionDataSummary");
            allRoles.add("Pension_PensionPlans_Read");
            allRoles.add("Pension_MonetaryTransaction_Read");
            allRoles.add("Pension_MonetaryTransactionTotals_Read");
            allRoles.add("Pension_RegularContributionInstructions_Read");
            allRoles.add("Pension_InvestmentStrategy_Read");
            allRoles.add("Pension_LifeCoverInst_Read");
            allRoles.add("Pension_LoyaltyBonuses_Read");
            allRoles.add("Pension_Funds_Read");
            allRoles.add("Pension_GroupPensions_Read");
            allRoles.add("Pension_GroupPensionSummaries_Read");
            allRoles.add("Pension_FundChoices_Read");
            allRoles.add("Pension_ConventionalValuations_Read");
            allRoles.add("Pension_Roles_Read");
            allRoles.add("Pension_Roles_Write");
            allRoles.add("Pension_NextContributions_Read");

            final UserCacheEntry user = new UserCacheEntry("PensionReadUser", "PensionReadUser", allRoles);
            final UserCacheEntry appianUser = new UserCacheEntry("AppianAccount", "AppianAccount", allRoles);
            final UserCacheEntry noRolesUser = new UserCacheEntry("NoRoles", "NoRoles", new HashSet<String>());

            repository.setUserEntry(user);
            repository.setUserEntry(appianUser);
            repository.setUserEntry(noRolesUser);

        } catch (final Exception e) {
            log.error("Failed to load config", e.getMessage());
        }
        return inputPath;
    }

}
