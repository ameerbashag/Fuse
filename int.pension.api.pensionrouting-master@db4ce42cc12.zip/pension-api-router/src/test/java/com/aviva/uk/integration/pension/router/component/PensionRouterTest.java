package com.aviva.uk.integration.pension.router.component;

import static org.junit.Assert.assertEquals;

import com.aviva.uk.integration.pension.response.bo.roles.PensionRoles;

import java.io.IOException;

import org.apache.camel.CamelContext;
import org.apache.camel.EndpointInject;
import org.apache.camel.builder.AdviceWithRouteBuilder;
import org.apache.camel.component.mock.MockEndpoint;
import org.apache.camel.model.ModelCamelContext;
import org.apache.camel.test.spring.CamelSpringJUnit4ClassRunner;
import org.apache.commons.codec.binary.Base64;
import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.codehaus.jackson.map.ObjectMapper;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.annotation.DirtiesContext.ClassMode;
import org.springframework.test.context.ContextConfiguration;

@RunWith(CamelSpringJUnit4ClassRunner.class)
@DirtiesContext(classMode = ClassMode.AFTER_EACH_TEST_METHOD)
@ContextConfiguration(locations = { "classpath:/META-INF/spring/camel-config.xml" })
/**
 * Component Test for PensionRouter that test for 401 & 403 error codes for api's contained in router
 *
 * @author renusea,salianl
 *
 */
public class PensionRouterTest {

    static String inputPath = null;

    @Autowired
    protected CamelContext context;

    @EndpointInject(uri = "mock:direct-vm:funds")
    protected MockEndpoint fundsEndpoint;

    @EndpointInject(uri = "mock:direct-vm:pension-api-roles-post")
    protected MockEndpoint postendRolesEndpoint;

    @EndpointInject(uri = "mock:direct-vm:pensionPlans")
    protected MockEndpoint pensionPlansEndpoint;

    @EndpointInject(uri = "mock:direct-vm:contributions")
    protected MockEndpoint nextContributionsEndpoint;

    @BeforeClass
    public static void beforeClass() throws Exception {

        inputPath = SetUpRolesAndUsers.initialize();
    }

    @Test
    public void test400BadRequest() throws ClientProtocolException, IOException {
        final DefaultHttpClient httpclient = new DefaultHttpClient();
        final HttpGet httpGet = new HttpGet(inputPath + "TK12345678/MonetaryTransactions");
        httpGet.setHeader("Authorization",
                "Basic " + Base64.encodeBase64String("PensionReadUser:PensionReadUser".getBytes()));

        httpGet.setHeader("Requesting-System", "");
        httpGet.setHeader("Accept", "application/json");

        final HttpResponse response = httpclient.execute(httpGet);
        assertEquals(400, response.getStatusLine().getStatusCode());
    }

    @Test
    public void test401Unathorized() throws ClientProtocolException, IOException {
        // invoke the route with invalid credentials
        final DefaultHttpClient httpclient = new DefaultHttpClient();
        final HttpGet httpGet = new HttpGet(inputPath + "TK12345678/groupPensionSummaries?enquiryDate=2016-02-05");
        httpGet.setHeader("Authorization", "Basic " + Base64.encodeBase64String("abc:abc".getBytes()));

        httpGet.setHeader("Requesting-System", "MyAviva");
        httpGet.setHeader("Accept", "application/json");

        final HttpResponse response = httpclient.execute(httpGet);
        assertEquals(401, response.getStatusLine().getStatusCode());
    }

    @Test
    public void testNoPlanNumberNoSubResourceRequest() throws ClientProtocolException, IOException {
        final DefaultHttpClient httpclient = new DefaultHttpClient();

        final HttpGet httpGet = new HttpGet(inputPath);

        httpGet.setHeader("Authorization",
                "Basic " + Base64.encodeBase64String("PensionReadUser:PensionReadUser".getBytes()));

        httpGet.setHeader("Requesting-System", "MyAviva");
        httpGet.setHeader("Accept", "application/json");

        final HttpResponse response = httpclient.execute(httpGet);
        assertEquals(400, response.getStatusLine().getStatusCode());

    }

    @Test
    public void testNoPlanNumberWithSubResourceRequest() throws ClientProtocolException, IOException {
        final DefaultHttpClient httpclient = new DefaultHttpClient();

        final HttpGet httpGet = new HttpGet(inputPath + "funds");

        httpGet.setHeader("Authorization",
                "Basic " + Base64.encodeBase64String("PensionReadUser:PensionReadUser".getBytes()));

        httpGet.setHeader("Requesting-System", "MyAviva");
        httpGet.setHeader("Accept", "application/json");

        final HttpResponse response = httpclient.execute(httpGet);
        assertEquals(400, response.getStatusLine().getStatusCode());

    }

    @Test
    public void testMisspeltSubResource() throws ClientProtocolException, IOException {
        final DefaultHttpClient httpclient = new DefaultHttpClient();

        final HttpGet httpGet = new HttpGet(inputPath + "TK12345678/fund");

        httpGet.setHeader("Authorization",
                "Basic " + Base64.encodeBase64String("PensionReadUser:PensionReadUser".getBytes()));

        httpGet.setHeader("Requesting-System", "MyAviva");
        httpGet.setHeader("Accept", "application/json");

        final HttpResponse response = httpclient.execute(httpGet);
        assertEquals(400, response.getStatusLine().getStatusCode());

    }

    @Test
    public void test403Forbidden() throws ClientProtocolException, IOException {
        // invoke the route with valid credentials
        final DefaultHttpClient httpclient = new DefaultHttpClient();
        final HttpGet httpGet = new HttpGet(inputPath + "TK12345678/groupPensionSummaries?enquiryDate=2016-02-05");
        httpGet.setHeader("Authorization", "Basic " + Base64.encodeBase64String("NoRoles:NoRoles".getBytes()));

        httpGet.setHeader("Requesting-System", "MyAviva");
        httpGet.setHeader("Accept", "application/json");

        final HttpResponse response = httpclient.execute(httpGet);
        assertEquals(403, response.getStatusLine().getStatusCode());
    }

    @Test
    public void testSuccessfulRouting() throws Exception {
        // invoke the route with invalid credentials
        final DefaultHttpClient httpclient = new DefaultHttpClient();
        final HttpGet httpGet = new HttpGet(inputPath + "TK12345678/funds?fundReference=1234");
        httpGet.setHeader("Authorization",
                "Basic " + Base64.encodeBase64String("PensionReadUser:PensionReadUser".getBytes()));

        httpGet.setHeader("Requesting-System", "MyAviva");
        httpGet.setHeader("Accept", "application/json");
        final ModelCamelContext modelContext = (ModelCamelContext) context;

        modelContext.getRouteDefinitions().get(0).adviceWith(modelContext, new AdviceWithRouteBuilder() {
            @Override
            public void configure() throws Exception {
                // Automatically replaces the funds call with the mocked equivalent (above) then skips the original
                // call.
                mockEndpointsAndSkip("direct-vm:funds");
            }
        });

        fundsEndpoint.expectedMessageCount(1);

        httpclient.execute(httpGet);
        fundsEndpoint.assertIsSatisfied();
    }

    @Test
    public void testSubSubResource() throws Exception {
        // invoke the route with invalid credentials
        final DefaultHttpClient httpclient = new DefaultHttpClient();
        final HttpPost httpPost = new HttpPost(inputPath + "TK12345678/roles/end");
        httpPost.setHeader("Authorization",
                "Basic " + Base64.encodeBase64String("AppianAccount:AppianAccount".getBytes()));

        httpPost.setHeader("Requesting-System", "MyAviva");
        httpPost.setHeader("Accept", "application/json");
        httpPost.setHeader("Content-Type", "application/json");
        PensionRoles roles = new PensionRoles();
        String requestJson = new ObjectMapper().writeValueAsString(roles);
        StringEntity request = new StringEntity(requestJson);
        httpPost.setEntity(request);

        final ModelCamelContext modelContext = (ModelCamelContext) context;

        modelContext.getRouteDefinitions().get(0).adviceWith(modelContext, new AdviceWithRouteBuilder() {
            @Override
            public void configure() throws Exception {
                // Automatically replaces the funds call with the mocked equivalent (above) then skips the original
                // call.
                mockEndpointsAndSkip("direct-vm:pension-api-roles-post");
            }
        });
        httpclient.execute(httpPost);

        postendRolesEndpoint.expectedMessageCount(1);
        postendRolesEndpoint.assertIsSatisfied();

    }

    @Test
    public void testPensionPlansResource() throws Exception {
        // invoke the route with invalid credentials
        final DefaultHttpClient httpclient = new DefaultHttpClient();
        final HttpGet httpGet = new HttpGet(inputPath + "TK12345678");
        httpGet.setHeader("Authorization",
                "Basic " + Base64.encodeBase64String("PensionReadUser:PensionReadUser".getBytes()));

        httpGet.setHeader("Requesting-System", "MyAviva");
        httpGet.setHeader("Accept", "application/json");
        final ModelCamelContext modelContext = (ModelCamelContext) context;

        modelContext.getRouteDefinitions().get(0).adviceWith(modelContext, new AdviceWithRouteBuilder() {
            @Override
            public void configure() throws Exception {
                // Automatically replaces the PensionPlans call with the mocked equivalent (above) then skips the
                // original
                // call.
                mockEndpointsAndSkip("direct-vm:pensionPlans");
            }
        });
        pensionPlansEndpoint.expectedMessageCount(1);

        httpclient.execute(httpGet);
        pensionPlansEndpoint.assertIsSatisfied();
    }

    @Test
    public void testNextContributionResource() throws Exception {
        // invoke the route with invalid credentials
        final DefaultHttpClient httpclient = new DefaultHttpClient();
        final HttpGet httpGet = new HttpGet(inputPath + "TK12345678/nextContributions?contributorType=Employer");
        httpGet.setHeader("Authorization",
                "Basic " + Base64.encodeBase64String("PensionReadUser:PensionReadUser".getBytes()));

        httpGet.setHeader("Requesting-System", "MyAviva");
        httpGet.setHeader("Accept", "application/json");
        final ModelCamelContext modelContext = (ModelCamelContext) context;

        modelContext.getRouteDefinitions().get(0).adviceWith(modelContext, new AdviceWithRouteBuilder() {
            @Override
            public void configure() throws Exception {
                // Automatically replaces the funds call with the mocked equivalent (above) then skips the original
                // call.
                mockEndpointsAndSkip("direct-vm:contributions");
            }
        });

        nextContributionsEndpoint.expectedMessageCount(1);

        httpclient.execute(httpGet);
        nextContributionsEndpoint.assertIsSatisfied();
    }
}
