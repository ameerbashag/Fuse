package com.aviva.uk.integration.pension.projection.bo;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;

import javax.xml.bind.JAXB;

import org.codehaus.jackson.JsonParseException;
import org.codehaus.jackson.map.ObjectMapper;
import org.json.JSONException;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.skyscreamer.jsonassert.JSONAssert;

public class ProjectionRequestTest {

    public static final String SRC_TEST_RESOURCES_BO_PROJECTION_REQUEST_JSON = "src/test/resources/bo/projection/request.json";
    public static final String FILE_SRC_TEST_RESOURCES_BO_PROJECTION_REQUEST_XML = "file:src/test/resources/bo/projection/request.xml";

    @Rule
    public ExpectedException exception = ExpectedException.none();

    @Test
    public void shouldProperlyMapJsonToObject() throws Exception {
        // given
        String requestJsonString = new String(
                Files.readAllBytes(Paths.get(SRC_TEST_RESOURCES_BO_PROJECTION_REQUEST_JSON)));
        ObjectMapper mapper = new ObjectMapper();
        // when
        ProjectionRequest projection = mapper.readValue(requestJsonString, ProjectionRequest.class);
        // then
        String resultRequestJson = mapper.writeValueAsString(projection);
        JSONAssert.assertEquals(requestJsonString, resultRequestJson, false);
    }

    @Test
    public void shouldProperlyMapObjectToJson() throws IOException {
        // given
        ObjectMapper mapper = new ObjectMapper();
        ProjectionRequest projection = mapper.readValue(new File(SRC_TEST_RESOURCES_BO_PROJECTION_REQUEST_JSON),
                ProjectionRequest.class);
        // when
        String mappedJson = mapper.writeValueAsString(projection);
        // then
        assertNotEquals(mappedJson.length(), 0);
    }

    @Test
    public void wrongJsonShouldBeMappedToEmptyObject() throws IOException {
        // given
        ObjectMapper mapper = new ObjectMapper();
        String wrongJson = "{\"value23\": \"sth\"}";
        // when
        ProjectionRequest projection = mapper.readValue(wrongJson, ProjectionRequest.class);
        // then
        assertEquals(projection.getQuotationType(), null);
    }

    @Test(expected = JsonParseException.class)
    public void notParsingJsonShouldThrowException() throws IOException {
        // given
        ObjectMapper mapper = new ObjectMapper();
        String wrongJson = "{\"sth\"}";
        // when
        ProjectionRequest projection = mapper.readValue(wrongJson, ProjectionRequest.class);
        // then JsonParseException
    }

    @Test
    public void mappedRequestXMLandRequestJsonShouldCreateSameObject() throws IOException, JSONException {
        // given
        ObjectMapper mapper = new ObjectMapper();
        ProjectionRequest projectionFromJson = mapper.readValue(new File(SRC_TEST_RESOURCES_BO_PROJECTION_REQUEST_JSON),
                ProjectionRequest.class);
        // when
        ProjectionRequest projectionFromXML = JAXB.unmarshal(FILE_SRC_TEST_RESOURCES_BO_PROJECTION_REQUEST_XML,
                ProjectionRequest.class);
        // then
        JSONAssert.assertEquals(mapper.writeValueAsString(projectionFromJson),
                mapper.writeValueAsString(projectionFromXML), false);
    }
}