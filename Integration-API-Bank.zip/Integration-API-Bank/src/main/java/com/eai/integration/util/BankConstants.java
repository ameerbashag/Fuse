package com.eai.integration.util;

/**
 * @author BASHAA
 *
 */
public class BankConstants {
	public static final String POLICY_NOT_FOUND = "Policy Reference not found";
	public static final String INVALID_POLICY = "Invalid Policy Reference";
	public static final String UNISURE_FAILURE = "Service Failure";
	public static final String REQ_VALIDATION_FAIL = "Request Validation Failure";
	public static final String PENSION_PRODUCTS_REQUEST = "PensionProductsRequest";
	public static final String RESOURCE_NAME = "pensionProducts";
	public static final String ACCOUNT_ID = "accountID";
	public static final String URI = "uri";
	public static final String SEPARATER = "/";
	public static final String SELF = "self";
	public static final int ERR_CODE_400 = 400;
	public static final int ERR_CODE_500 = 500;
	public static final String PLANNUMBER_REQUIRED = "Parameter planNumber is required";
	public static final int ERR_CODE_404 = 404;
	public static final String REQUESTING_SYSTEM = "Requesting-System";
	public static final String CORRELATION_ID = "Correlation-ID";
	public static final String INTERNAL_SERVER_ERROR = "Internal Server Error";
	public static final String INTERNAL_PROCESSING_ERROR = "Internal Processing error";
	public static final String WCF_SECURITY_USER_INFO= "User-Info";
	
	private BankConstants() {
        // Empty private constructor
    }
}