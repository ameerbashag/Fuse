/**
 * 
 */
package com.eai.integration.exception;

/**
 * @author AKSHAJ
 *
 */
public class ProblemDetailsException {

}
