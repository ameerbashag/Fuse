/**
 * 
 */
package com.eai.integration.mapper;

import javax.ws.rs.PathParam;
import org.apache.camel.Exchange;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.eai.integration.exception.ProblemDetailsException;
import com.eai.integration.util.BankConstants;

/**
 * @author AKSHAJ
 *
 */
public class DataMapper {

	private static final Logger LOG = LoggerFactory.getLogger(DataMapper.class);

	/**
	 * @param planNumber
	 * @param exchange
	 * @throws ProblemDetailsException
	 */

	public void mapHttpRequest(@PathParam("accountID") String accountID, Exchange exchange)
			throws Exception {
		LOG.debug("Account ID ::: " + accountID);
		exchange.setProperty(BankConstants.URI,
				exchange.getIn().getHeader(BankConstants.URI, String.class));
		exchange.setProperty(BankConstants.REQUESTING_SYSTEM,
				exchange.getIn().getHeader(BankConstants.REQUESTING_SYSTEM, String.class));
		exchange.setProperty(BankConstants.ACCOUNT_ID, accountID);
	}
}
