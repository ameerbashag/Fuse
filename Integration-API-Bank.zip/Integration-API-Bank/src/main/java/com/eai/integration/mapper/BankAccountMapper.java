/**
 * 
 */
package com.eai.integration.mapper;

import org.apache.camel.Exchange;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.eai.integration.bo.BankAccount;
import com.eai.integration.util.BankConstants;

/**
 * @author AKSHAJ
 *
 */
public class BankAccountMapper {
	private static final Logger LOG = LoggerFactory.getLogger(BankAccountMapper.class);
	
	public void mapResponse(Exchange exchange) throws Exception {
        LOG.debug("********** Inside mapResponse **********" + exchange);
        BankAccount bankAccount = new BankAccount();
        bankAccount.setAccountID(exchange.getProperty(BankConstants.ACCOUNT_ID, int.class));
        bankAccount.setId("555888");
        bankAccount.setType("SA");;
        exchange.getIn().setBody(bankAccount);
    }


}
