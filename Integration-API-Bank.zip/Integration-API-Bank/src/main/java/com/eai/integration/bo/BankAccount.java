/**
 * 
 */
package com.eai.integration.bo;

/**
 * @author AKSHAJ
 *
 */
public class BankAccount {
	
	private String id;
	private int accountID;
	private String type;
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public int getAccountID() {
		return accountID;
	}
	public void setAccountID(int accountID) {
		this.accountID = accountID;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	

}
