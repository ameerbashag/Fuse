package com.eai.integration.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;
import com.eai.integration.bo.BankAccount;

@RepositoryRestResource
public interface BankAccountRepository extends CrudRepository<BankAccount, Integer>{
	BankAccount findByID(Integer ID);

}