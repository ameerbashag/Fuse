package com.eai.integration;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.apache.camel.Body;

import com.eai.integration.bo.BankAccount;

@Path("/banks")
public class BankAccountResource {

    @GET
    @Path("/accounts/{ACCOUNT_ID}")
    @Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
    @Consumes({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
    public BankAccount getAccountById(@PathParam("ACCOUNT_ID") String ACCOUNT_ID) {
        return null;
    }

    @POST
    @Path("/accounts")
    @Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML, MediaType.TEXT_XML, "application/problem+json" })
    @Consumes({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON, "application/problem+json" })
    public Object createAccount(@Body BankAccount bankAccount) {
        return null;
    }
    
    @PUT
    @Path("/accounts/{ACCOUNT_ID}")
    @Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
    @Consumes({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
    public BankAccount updateAccount(@PathParam("ACCOUNT_ID") String ACCOUNT_ID, @Body BankAccount bankAccount) {
        return null;
    }
    
    @DELETE
    @Path("/accounts/{ACCOUNT_ID}")
    @Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
    @Consumes({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
    public void deleteAccount(@PathParam("ACCOUNT_ID") String ACCOUNT_ID) {

    }

}
