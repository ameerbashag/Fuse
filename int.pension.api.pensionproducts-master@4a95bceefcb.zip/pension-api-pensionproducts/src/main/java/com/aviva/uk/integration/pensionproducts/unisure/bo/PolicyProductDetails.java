package com.aviva.uk.integration.pensionproducts.unisure.bo;

import javax.xml.bind.annotation.XmlType;
import org.codehaus.jackson.annotate.JsonProperty;
import org.codehaus.jackson.annotate.JsonPropertyOrder;
import org.codehaus.jackson.map.annotate.JsonSerialize;

/**
 * @author BASHAA
 *
 */
@JsonSerialize(include = JsonSerialize.Inclusion.NON_NULL)
@XmlType(propOrder = { "Extpolref", "Prdref", "Prdvrs_no", "Response_msg" })
@JsonPropertyOrder({ "Extpolref", "Prdref", "Prdvrs_no", "Response_msg" })
public class PolicyProductDetails {

	@JsonProperty("Extpolref")
	private String extpolref;
	@JsonProperty("Prdref")
	private String prdref;
	@JsonProperty("Prdvrs_no")
	private String prdvrsNo;
	@JsonProperty("Response_msg")
	private String responseMsg;

	/**
	 * 
	 * @return The Extpolref
	 */
	@JsonProperty("Extpolref")
	public String getExtpolref() {
		return extpolref;
	}

	/**
	 * 
	 * @param Extpolref
	 *            The Extpolref
	 */
	@JsonProperty("Extpolref")
	public void setExtpolref(String extpolref) {
		this.extpolref = extpolref;
	}

	/**
	 * 
	 * @return The Prdref
	 */
	@JsonProperty("Prdref")
	public String getPrdref() {
		return prdref;
	}

	/**
	 * 
	 * @param Prdref
	 *            The Prdref
	 */
	@JsonProperty("Prdref")
	public void setPrdref(String prdref) {
		this.prdref = prdref;
	}

	/**
	 * 
	 * @return The PrdvrsNo
	 */
	@JsonProperty("Prdvrs_no")
	public String getPrdvrsNo() {
		return prdvrsNo;
	}

	/**
	 * 
	 * @param PrdvrsNo
	 *            The Prdvrs_no
	 */
	@JsonProperty("Prdvrs_no")
	public void setPrdvrsNo(String prdvrsNo) {
		this.prdvrsNo = prdvrsNo;
	}

	/**
	 * 
	 * @return The ResponseMsg
	 */
	@JsonProperty("Response_msg")
	public String getResponseMsg() {
		return responseMsg;
	}

	/**
	 * 
	 * @param ResponseMsg
	 *            The Response_msg
	 */
	@JsonProperty("Response_msg")
	public void setResponseMsg(String responseMsg) {
		this.responseMsg = responseMsg;
	}
}