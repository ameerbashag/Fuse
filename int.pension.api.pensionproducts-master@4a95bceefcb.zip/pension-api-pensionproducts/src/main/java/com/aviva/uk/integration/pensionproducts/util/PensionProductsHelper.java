/**
 * 
 */
package com.aviva.uk.integration.pensionproducts.util;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @author bashaa
 *
 */
public class PensionProductsHelper {

	private static final Logger LOG = LoggerFactory.getLogger(PensionProductsHelper.class);
	
	/**
     * This method sets correlationId for BaNCS request .
     *
     * @param correlationId
     */
    public String setXguid(final String correlationId) {
        LOG.debug("Mapping setXguid ");
        String xGuid;
        if (null != correlationId) {
            if (correlationId.length() > 36) {
                xGuid = correlationId.replace("uuid:", "");
                if (xGuid.length() > 36) {
                    xGuid = xGuid.substring(0, 36);
                }
                return xGuid;
            } else {
                return correlationId;
            }
        }
        return correlationId;
    }
}
