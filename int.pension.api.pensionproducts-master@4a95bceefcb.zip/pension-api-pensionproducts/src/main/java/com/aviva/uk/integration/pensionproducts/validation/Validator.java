/**
 * 
 */
package com.aviva.uk.integration.pensionproducts.validation;

import org.apache.camel.Exchange;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.aviva.uk.integration.errorhandling.ProblemDetailsException;
import com.aviva.uk.integration.pensionproducts.util.PensionProductsConstants;

/**
 * @author BASHAA 
 *
 */
public class Validator {
	private static final Logger LOG = LoggerFactory
			.getLogger(Validator.class);
	
	/**
	 * @param exchange
	 * @throws ProblemDetailsException
	 */
	public void validate(Exchange exchange) throws ProblemDetailsException{
		LOG.debug(" inside validate  ");
		if(StringUtils.isBlank((String) exchange.getProperty(PensionProductsConstants.PLAN_NUMBER))){
			LOG.error(" Validation Failed ::: Parameter planNumber is required  ");
			throw new ProblemDetailsException(PensionProductsConstants.ERR_CODE_400,PensionProductsConstants.REQ_VALIDATION_FAIL, PensionProductsConstants.PLANNUMBER_REQUIRED);
		}
	}
	
}