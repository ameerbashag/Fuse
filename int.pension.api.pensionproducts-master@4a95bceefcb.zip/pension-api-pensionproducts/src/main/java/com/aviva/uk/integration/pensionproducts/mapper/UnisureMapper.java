/**
 * 
 */
package com.aviva.uk.integration.pensionproducts.mapper;

import com.aviva.uk.integration.errorhandling.ProblemDetailsException;
import com.aviva.uk.integration.hypermedia.Link;
import com.aviva.uk.integration.logging.MDCConstants;
import com.aviva.uk.integration.pension.response.bo.products.PensionProductsResponse;
import com.aviva.uk.integration.pension.response.bo.products.ProductDetails;
import com.aviva.uk.integration.pensionproducts.unisure.bo.PolicyProductDetails;
import com.aviva.uk.integration.pensionproducts.util.PensionProductsConstants;
import com.aviva.uk.integration.pensionproducts.util.PensionProductsHelper;

import javax.ws.rs.core.MediaType;

import org.apache.camel.Exchange;
import org.apache.camel.component.cxf.common.message.CxfConstants;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;

/**
 * @author BASHAA
 *
 */
public class UnisureMapper {
    private static final Logger LOG = LoggerFactory.getLogger(UnisureMapper.class);

    public void mapRequest(Exchange exchange) throws ProblemDetailsException {
        LOG.debug("######### Mapping Wcf service request ##########");
        String planNumber = exchange.getProperty(PensionProductsConstants.PLAN_NUMBER, String.class);
        String requestingSystem = exchange.getProperty(PensionProductsConstants.REQUESTING_SYSTEM, String.class);
        exchange.getIn().setHeader(Exchange.HTTP_METHOD, "GET");
        exchange.getIn().setHeader(Exchange.HTTP_PATH, planNumber);
        exchange.getIn().setHeader(Exchange.HTTP_PATH, planNumber);
        exchange.getIn().setHeader(PensionProductsConstants.REQUESTING_SYSTEM, requestingSystem);
        exchange.getIn().setHeader(PensionProductsConstants.CORRELATION_ID,
                new PensionProductsHelper().setXguid(MDC.get(MDCConstants.ESB_GUID)));
        exchange.getIn().setHeader(Exchange.ACCEPT_CONTENT_TYPE, MediaType.APPLICATION_JSON);
        exchange.getIn().setHeader(CxfConstants.CAMEL_CXF_RS_RESPONSE_CLASS, PolicyProductDetails.class);
        LOG.debug("######### Mapping Wcf service request done ##########");
    }

    public void mapResponse(Exchange exchange) throws ProblemDetailsException {
        LOG.debug("********** UnisureResponse **********" + exchange);
        exchange.getIn().setHeader(PensionProductsConstants.CORRELATION_ID,
                new PensionProductsHelper().setXguid(MDC.get(MDCConstants.ESB_GUID)));
        PolicyProductDetails getProductDetailsResponse = exchange.getIn().getBody(PolicyProductDetails.class);
        LOG.debug("********** getProductDetailsResponse **********" + getProductDetailsResponse.getExtpolref());
        PensionProductsResponse pensionProductsResponse = null;
        ProductDetails productDetails = null;
        if (getProductDetailsResponse != null) {
            pensionProductsResponse = new PensionProductsResponse();
            productDetails = new ProductDetails();
            if (StringUtils.isNotBlank(getProductDetailsResponse.getExtpolref())) {
                pensionProductsResponse.setPlanNumber(getProductDetailsResponse.getExtpolref());
            }
            if (StringUtils.isNotBlank(getProductDetailsResponse.getPrdref())) {
                productDetails.setProductReference(getProductDetailsResponse.getPrdref());
            }
            if (StringUtils.isNotBlank(getProductDetailsResponse.getPrdvrsNo())) {
                productDetails.setProductVersionNumber(getProductDetailsResponse.getPrdvrsNo());
            }
            productDetails.setOriginatingSystem(PensionProductsConstants.ORIGINATING_SYSTEM);
            StringBuilder url = new StringBuilder();
            url.append((String) exchange.getProperty(PensionProductsConstants.URI))
                    .append(PensionProductsConstants.SEPARATER)
                    .append((String) exchange.getProperty(PensionProductsConstants.PLAN_NUMBER))
                    .append(PensionProductsConstants.SEPARATER).append(PensionProductsConstants.RESOURCE_NAME);
            if (StringUtils.isNotBlank(getProductDetailsResponse.getResponseMsg())
                    && PensionProductsConstants.UNISURE_SUCCESS.equalsIgnoreCase(getProductDetailsResponse
                            .getResponseMsg())) {
                pensionProductsResponse.setProductDetails(productDetails);
                pensionProductsResponse.add(PensionProductsConstants.SELF, new Link(url.toString()));
                exchange.getIn().setBody(pensionProductsResponse);
            } else if (!PensionProductsConstants.UNISURE_SUCCESS.equals(getProductDetailsResponse.getResponseMsg())) {
                mapErrorDetails(getProductDetailsResponse);
            }
        }

    }

    private void mapErrorDetails(PolicyProductDetails getProductDetailsResponse) throws ProblemDetailsException {
        if (PensionProductsConstants.POLICY_NOT_FOUND.equals(getProductDetailsResponse.getResponseMsg())) {
            LOG.error(" Error From Unisure ::: Policy Reference not found  ");
            throw new ProblemDetailsException(PensionProductsConstants.ERR_CODE_500,
                    PensionProductsConstants.UNISURE_FAILURE, getProductDetailsResponse.getResponseMsg());
        } else if (PensionProductsConstants.INVALID_POLICY.equals(getProductDetailsResponse.getResponseMsg())) {
            LOG.error(" Error From Unisure ::: Invalid Policy Reference  ");
            throw new ProblemDetailsException(PensionProductsConstants.ERR_CODE_400,
                    PensionProductsConstants.REQ_VALIDATION_FAIL, getProductDetailsResponse.getResponseMsg());
        } else {
            LOG.error(" Error From Unisure ::: Unexpected error from Unisure  ");
            throw new ProblemDetailsException(PensionProductsConstants.ERR_CODE_500,
                    PensionProductsConstants.UNISURE_FAILURE, getProductDetailsResponse.getResponseMsg());
        }
    }

}