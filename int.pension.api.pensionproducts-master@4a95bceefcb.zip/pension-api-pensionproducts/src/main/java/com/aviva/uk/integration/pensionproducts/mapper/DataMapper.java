package com.aviva.uk.integration.pensionproducts.mapper;



import javax.ws.rs.PathParam;
import org.apache.camel.Exchange;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.aviva.uk.integration.errorhandling.ProblemDetailsException;
import com.aviva.uk.integration.pensionproducts.util.PensionProductsConstants;


/**
 * @author BASHAA
 * 
 */

public class DataMapper {

	private static final Logger LOG = LoggerFactory.getLogger(DataMapper.class);
	
	/**
	 * @param planNumber
	 * @param exchange
	 * @throws ProblemDetailsException 
	 */
	public void mapHttpRequest(@PathParam("planNumber") String planNumber,
			Exchange exchange) throws ProblemDetailsException {
		LOG.debug("Pension Products Request ::: " + planNumber);
		exchange.setProperty(PensionProductsConstants.URI,exchange.getIn().getHeader(PensionProductsConstants.URI,String.class));
		exchange.setProperty(PensionProductsConstants.REQUESTING_SYSTEM,exchange.getIn().getHeader(PensionProductsConstants.REQUESTING_SYSTEM,String.class));
		exchange.setProperty(PensionProductsConstants.PLAN_NUMBER, planNumber);
	}
	
}