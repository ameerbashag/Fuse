package com.aviva.uk.integration.pensionproducts.unittest;

import static org.junit.Assert.*;
import static org.mockito.Mockito.when;

import java.io.File;

import org.apache.camel.CamelContext;
import org.apache.camel.Exchange;
import org.apache.camel.Message;
import org.apache.camel.component.cxf.common.message.CxfConstants;
import org.apache.camel.impl.DefaultCamelContext;
import org.apache.camel.impl.DefaultExchange;
import org.codehaus.jackson.map.ObjectMapper;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.powermock.modules.junit4.PowerMockRunner;

import com.aviva.uk.integration.errorhandling.ProblemDetailsException;
import com.aviva.uk.integration.pensionproducts.mapper.DataMapper;
import com.aviva.uk.integration.pensionproducts.mapper.UnisureMapper;
import com.aviva.uk.integration.pensionproducts.unisure.bo.PolicyProductDetails;
import com.aviva.uk.integration.pensionproducts.util.PensionProductsConstants;
import com.aviva.uk.integration.pensionproducts.validation.Validator;

/**
 * @author BASHAA
 * 
 */

@RunWith(PowerMockRunner.class)
public class PensionProductsUnitTest {

	@Mock
	Exchange exchange;

	@Mock
	Message message;
	
	private static PolicyProductDetails invalidPolicyResponse;
	private static PolicyProductDetails policyNotFound;

	@Before
	public void setUp() throws Exception {
		when(exchange.getIn()).thenReturn(message);
	}
	
	public void loadServiceResponses() throws Exception {
		ObjectMapper objectMapper = new ObjectMapper();

		invalidPolicyResponse = objectMapper.readValue(
				new File("src/test/resources/response/unisure/InvalidPolicy.json"), PolicyProductDetails.class);
		policyNotFound = objectMapper.readValue(
				new File("src/test/resources/response/unisure/Failure.json"), PolicyProductDetails.class);
	}

	/**
	 * Valid Request should Not return any Exception
	 * 
	 * @throws ProblemDetailsException
	 */
	
	@Test
	public void testValidPolicyNumber() throws ProblemDetailsException {
		when(exchange.getProperty(PensionProductsConstants.PLAN_NUMBER)).thenReturn("TK10000124");
		new Validator().validate(exchange);
		assertEquals("TK10000124", exchange.getProperty(PensionProductsConstants.PLAN_NUMBER));
	}
	
	@Test
	public void testBlankPolicyNumber() throws ProblemDetailsException {
		try{
			when(exchange.getProperty(PensionProductsConstants.PLAN_NUMBER)).thenReturn(null);
			new Validator().validate(exchange);
		}catch (ProblemDetailsException e) {
			assertEquals(PensionProductsConstants.ERR_CODE_400, e.getProblemDetails().getStatus());
			assertEquals(PensionProductsConstants.REQ_VALIDATION_FAIL, e.getProblemDetails().getTitle());
			assertEquals(PensionProductsConstants.PLANNUMBER_REQUIRED, e.getProblemDetails().getDetail());
		}
		
	}
	

	@Test
	public void testMapRequest() throws ProblemDetailsException {
		CamelContext ctx = new DefaultCamelContext();
		Exchange ex = new DefaultExchange(ctx);
		ex.setProperty(PensionProductsConstants.PLAN_NUMBER,"TK10000124");
		UnisureMapper unisureMapper = new UnisureMapper();
		unisureMapper.mapRequest(ex);
		assertEquals(PolicyProductDetails.class, ex.getIn().getHeader(CxfConstants.CAMEL_CXF_RS_RESPONSE_CLASS));
	}
	
	@Test
	public void testInvalidPolicy() throws Exception {
		try {
			CamelContext ctx = new DefaultCamelContext();
			Exchange ex = new DefaultExchange(ctx);
			loadServiceResponses();
			ex.getIn().setHeader("uri", "http://localhost:9007/v1/pensionPlans");
			ex.getIn().setBody(invalidPolicyResponse);
			UnisureMapper unisureMapper = new UnisureMapper();
			unisureMapper.mapResponse(ex);
		} catch (ProblemDetailsException e) {
			assertEquals(PensionProductsConstants.ERR_CODE_400, e.getProblemDetails().getStatus());
			assertEquals(PensionProductsConstants.REQ_VALIDATION_FAIL, e.getProblemDetails().getTitle());
			assertEquals(PensionProductsConstants.INVALID_POLICY, e.getProblemDetails().getDetail());
		}
	}
	
	@Test
	public void testPolicyNotFoundResponse() throws Exception {
		try {
			CamelContext ctx = new DefaultCamelContext();
			Exchange ex = new DefaultExchange(ctx);
			loadServiceResponses();
			ex.getIn().setHeader("uri", "http://localhost:9007/v1/pensionPlans");
			ex.getIn().setBody(policyNotFound);
			UnisureMapper unisureMapper = new UnisureMapper();
			unisureMapper.mapResponse(ex);
		} catch (ProblemDetailsException e) {
			assertEquals(PensionProductsConstants.ERR_CODE_500, e.getProblemDetails().getStatus());
			assertEquals(PensionProductsConstants.UNISURE_FAILURE, e.getProblemDetails().getTitle());
			assertEquals(PensionProductsConstants.POLICY_NOT_FOUND, e.getProblemDetails().getDetail());
		}
	}
	//Requesting-System mapping test case
	@Test
    public void testHttpMapRequest() throws ProblemDetailsException {
        CamelContext ctx = new DefaultCamelContext();
        Exchange exchange = new DefaultExchange(ctx);
        exchange.getIn().setHeader(PensionProductsConstants.REQUESTING_SYSTEM,"Appian");
        DataMapper mapper = new DataMapper();
        mapper.mapHttpRequest("TK12345678",exchange);
        assertEquals("Appian", exchange.getProperty(PensionProductsConstants.REQUESTING_SYSTEM));
    }
    
}