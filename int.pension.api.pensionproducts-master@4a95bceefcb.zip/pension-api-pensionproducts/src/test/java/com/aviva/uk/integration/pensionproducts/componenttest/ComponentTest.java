package com.aviva.uk.integration.pensionproducts.componenttest;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import com.aviva.uk.integration.pension.response.bo.products.PensionProductsResponse;
import com.aviva.uk.integration.pensionproducts.unisure.bo.PolicyProductDetails;
import com.aviva.uk.integration.pensionproducts.util.PensionProductsConstants;
import com.aviva.uk.integration.test.HTTPUtils;

import java.io.File;

import org.apache.camel.CamelContext;
import org.apache.camel.EndpointInject;
import org.apache.camel.Exchange;
import org.apache.camel.Expression;
import org.apache.camel.Message;
import org.apache.camel.Produce;
import org.apache.camel.ProducerTemplate;
import org.apache.camel.builder.AdviceWithRouteBuilder;
import org.apache.camel.component.mock.MockEndpoint;
import org.apache.camel.model.ModelCamelContext;
import org.apache.camel.test.spring.CamelSpringJUnit4ClassRunner;
import org.codehaus.jackson.map.ObjectMapper;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.annotation.DirtiesContext.ClassMode;
import org.springframework.test.context.ContextConfiguration;

/**
 * @author BASHAA
 * 
 */
@RunWith(CamelSpringJUnit4ClassRunner.class)
@DirtiesContext(classMode = ClassMode.AFTER_EACH_TEST_METHOD)
@ContextConfiguration(locations = { "classpath:/META-INF/spring/camel-config.xml" })
public class ComponentTest {

    private static Logger log = LoggerFactory.getLogger(ComponentTest.class);

    @Autowired
    protected CamelContext context;

    Exchange exchange;
    Message message;
    @Produce(uri = "direct-vm:pensionProducts")
    protected ProducerTemplate producerTemplate;

    @EndpointInject(uri = "mock:cxf:bean:UnisureEndpoint")
    protected MockEndpoint mockUnisureEndpoint;

    @EndpointInject(uri = "mock:wcfSecurity")
    protected MockEndpoint mockWcfSecurity;

    private static PolicyProductDetails successUnisureResponse;

    private static String inputPath;

    @Before
    public void setUp() throws Exception {
        final int inputPort = HTTPUtils.getAvailablePort();

        log.debug("inbound port will be: " + inputPort);

        inputPath = "https://localhost:8443/api/v1/pensionPlans";
        System.setProperty("inboundURL", inputPath);
        log.debug("inputPath: " + inputPath);
        loadServiceResponses();
    }

    public void loadServiceResponses() throws Exception {
        ObjectMapper objectMapper = new ObjectMapper();
        successUnisureResponse = objectMapper.readValue(new File("src/test/resources/response/unisure/Success.json"),
                PolicyProductDetails.class);
    }

    @Test
    public void testSucessResponse() throws Exception {
        // Set up Routing mock
        final ModelCamelContext modelContext = (ModelCamelContext) context;
        mockUnisureWcfSecurity(modelContext);
        mockSuccessUnisureResponse(modelContext);
        final PensionProductsResponse actualResponse = (PensionProductsResponse) producerTemplate.requestBodyAndHeader(
                "direct-vm:pensionProducts", successUnisureResponse, "uri", inputPath);
        UnisureSuccessAssertion(actualResponse);
    }

    private void UnisureSuccessAssertion(PensionProductsResponse actualResponse) {
        assertEquals("TK10000124", actualResponse.getPlanNumber());
        assertEquals("PPP00UK", actualResponse.getProductDetails().getProductReference());
        assertEquals("2", actualResponse.getProductDetails().getProductVersionNumber());
        assertEquals("Unisure", actualResponse.getProductDetails().getOriginatingSystem());
    }

    private void mockSuccessUnisureResponse(ModelCamelContext modelContext) throws Exception {
        modelContext.getRouteDefinition("UnisureRoute").adviceWith(modelContext, new AdviceWithRouteBuilder() {
            @Override
            public void configure() throws Exception {
                weaveById("UNISURE").replace().to("mock:cxf:bean:UnisureEndpoint");
            }
        });
        // Assert to check if unisure is up and available in context
        assertNotNull(context.hasEndpoint("mock:cxf:bean:UnisureEndpoint"));
        mockUnisureEndpoint.returnReplyBody(new Expression() {
            @Override
            public <T> T evaluate(Exchange exchange, Class<T> type) {
                // Setting the error Code
                return exchange.getContext().getTypeConverter().convertTo(type, successUnisureResponse);
            }
        });
    }

    private void mockUnisureWcfSecurity(ModelCamelContext modelContext) throws Exception {
        modelContext.getRouteDefinition("UnisureRoute").adviceWith(modelContext, new AdviceWithRouteBuilder() {
            @Override
            public void configure() throws Exception {
                weaveById("getProductDetailsWCFBeanID").replace().to("mock:wcfSecurity");
            }
        });
        // Assert to check if unisure WCF is up and available in context
        assertNotNull(context.hasEndpoint("mock:wcfSecurity"));
        mockWcfSecurity.returnReplyHeader(PensionProductsConstants.WCF_SECURITY_USER_INFO, new Expression() {
            @Override
            public <T> T evaluate(Exchange exchange, Class<T> type) {
                return exchange.getContext().getTypeConverter().convertTo(type, "sfdgsdfgsdfgsdf");
            }
        });
    }
}