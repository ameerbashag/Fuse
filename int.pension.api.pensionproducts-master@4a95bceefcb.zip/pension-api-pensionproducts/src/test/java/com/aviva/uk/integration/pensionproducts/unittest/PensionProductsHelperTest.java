/**
 * 
 */
package com.aviva.uk.integration.pensionproducts.unittest;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;

import org.junit.Test;

import com.aviva.uk.integration.errorhandling.ProblemDetailsException;
import com.aviva.uk.integration.pensionproducts.util.PensionProductsHelper;

/**
 * @author naphadn
 *
 */
public class PensionProductsHelperTest {

    /**
     * Length of CorrealationId is greater than 36
     *
     * @throws ProblemDetailsException
     */
    @Test
    public void testSetXguid() throws ProblemDetailsException {
        String correalationId = new PensionProductsHelper().setXguid("uuid:516ee074-36b3-48f1-995d-8516db53e4c7");
        assertEquals(36, correalationId.length());
        assertEquals("516ee074-36b3-48f1-995d-8516db53e4c7", correalationId);
    }


    /**
     * Length of CorrealationId is less than 36
     *
     * @throws ProblemDetailsException
     */
    @Test
    public void testSetXguidCorrealationIdLessThan36() throws ProblemDetailsException {
        String correalationId =new PensionProductsHelper().setXguid("995d-8516db53e4");
        assertEquals(15, correalationId.length());
        assertEquals("995d-8516db53e4", correalationId);
    }

    /**
     * CorrealationId is null
     *
     * @throws ProblemDetailsException
     */
    @Test
    public void testSetXguidCorrealationIdNull() throws ProblemDetailsException {
        String correalationId = new PensionProductsHelper().setXguid(null);
        assertNull(correalationId);
    }
}
