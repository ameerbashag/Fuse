package utility;

import java.io.IOException;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.security.cert.X509Certificate;

import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

import org.apache.commons.codec.binary.Base64;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.config.Registry;
import org.apache.http.config.RegistryBuilder;
import org.apache.http.conn.HttpClientConnectionManager;
import org.apache.http.conn.socket.ConnectionSocketFactory;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.impl.conn.BasicHttpClientConnectionManager;
import org.apache.http.util.EntityUtils;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import pensionProductsAPI.support.PensionProductsAPI;

public class HTTPUtil {

	private static final String HTTP_HEADER_ACCEPT = "application/json";
	private static final String HTTP_HEADER_CONTENT_TYPE = "application/json";
	//private static final String HTTP_HEADER_REQUESTING_SYSTEM = "test";
	private static String httpHeaderRequestingSystem;
	private static final String HTTP_HEADER_CORRELATION_ID = "test";
	private static String HTTP_HEADER_AUTHORIZATION;
	public static String getHTTP_HEADER_AUTHORIZATION() {
		return HTTP_HEADER_AUTHORIZATION;
	}

	public static void setHTTP_HEADER_AUTHORIZATION(String hTTP_HEADER_AUTHORIZATION) {
		HTTP_HEADER_AUTHORIZATION = hTTP_HEADER_AUTHORIZATION;
	}

	final static Logger logger = LoggerFactory.getLogger(HTTPUtil.class);



	/**
	 * Call the API using HTTP GET and save the response
	 *
	 * @param protocol
	 * @throws IOException
	 * @throws ClientProtocolException
	 */
	public static void httpGet(String url, String protocol) {

		CloseableHttpClient httpclient;
		try {
			httpclient = (protocol.equalsIgnoreCase("HTTP")) ? HttpClients.createDefault() : createSSLHttpClientBuilder().build();

			final HttpGet httpGet = new HttpGet(url);
			// Set HTTP Headers
			httpGet.setHeader("Accept", HTTP_HEADER_ACCEPT);
			//httpGet.setHeader("Requesting-System", HTTP_HEADER_REQUESTING_SYSTEM);
			httpGet.setHeader("Requesting-System",httpHeaderRequestingSystem);
			httpGet.setHeader("Correlation-ID", HTTP_HEADER_CORRELATION_ID);
			httpGet.setHeader("Authorization", getHTTP_HEADER_AUTHORIZATION());

			// Make the call and save results
			final CloseableHttpResponse response = httpclient.execute(httpGet);
			String responseString = null;
			try {
				logger.info("httpGet Status Line {}", response.getStatusLine());
				PensionProductsAPI.setHttpStatusCode(response.getStatusLine().getStatusCode());
				if (response.getStatusLine().getStatusCode() == 200) {
					responseString = EntityUtils.toString(response.getEntity());
					logger.info("httpGet Response {}", responseString);
					PensionProductsAPI.setResponseJson(new JSONObject(responseString));
				}
				else
				{
					responseString = EntityUtils.toString(response.getEntity());
					logger.info("httpGet Response {}", responseString);
					PensionProductsAPI.setResponseJson(new JSONObject(responseString));
				}
			} finally {
				response.close();
				httpclient.close();
			}

		} catch (KeyManagementException | NoSuchAlgorithmException | IOException e) {
			e.printStackTrace();
		}
	}
	
	public static String getHttpHeaderRequestingSystem() {
        return httpHeaderRequestingSystem;
      }

    public static void setHttpHeaderRequestingSystem(String httpHeaderRequestingSystem) {
        HTTPUtil.httpHeaderRequestingSystem = httpHeaderRequestingSystem;
        
    }

	/**
	 * Call the API using HTTP POST and save the response
	 *
	 * @throws IOException
	 * @throws ClientProtocolException
	 * @throws NoSuchAlgorithmException
	 * @throws KeyManagementException
	 */
	public static void httpPost(String url,   String protocol) {

		try {
			final CloseableHttpClient httpclient = (protocol.equalsIgnoreCase("HTTP")) ? HttpClients.createDefault()
					: createSSLHttpClientBuilder().build();

			// Generate URI
			final HttpPost httpPost = new HttpPost(url);

			// Set HTTP Headers
			httpPost.setHeader("Accept", HTTP_HEADER_ACCEPT);
			httpPost.setHeader("Content-Type", HTTP_HEADER_CONTENT_TYPE);
			//httpPost.setHeader("Requesting-System", HTTP_HEADER_REQUESTING_SYSTEM);  
			httpPost.setHeader("Requesting-System", httpHeaderRequestingSystem);
			httpPost.setHeader("Correlation-ID", HTTP_HEADER_CORRELATION_ID);
			httpPost.setHeader("Authorization", getHTTP_HEADER_AUTHORIZATION());

			// Set the request message
			// StringEntity request = new StringEntity(requestJson.toString());
			// httpPost.setEntity(request);

			// Make the call and save results
			final CloseableHttpResponse response = httpclient.execute(httpPost);
			String responseString = null;
			try {
				logger.info("httpPost Status Line {}", response.getStatusLine());
				PensionProductsAPI.setHttpStatusCode(response.getStatusLine().getStatusCode());
				if (response.getStatusLine().getStatusCode() == 201) {
					responseString = EntityUtils.toString(response.getEntity());
					logger.info("httpGet Response {}", responseString);
					PensionProductsAPI.setResponseJson(new JSONObject(responseString));
				}
			} finally {
				response.close();
				httpclient.close();
			}

		} catch (KeyManagementException | NoSuchAlgorithmException | IOException e) {
			e.printStackTrace();
		}
	}

	/**
	 * Accepts a user id and password and returns a base 64 encoded header
	 */
	public static String getAuthorizationHeadder(String user, String password) {

		final String creds = user + ":" + password;
		final String authHeader = "Basic " + new String(Base64.encodeBase64((creds).getBytes()));
		logger.info("Auth headder {}, {}, {}", user, password, authHeader);

		return authHeader;
	}

	/**
	 * Create SSL context
	 *
	 * @return
	 * @throws NoSuchAlgorithmException
	 * @throws KeyManagementException
	 */
	public static SSLContext createSSLContext() throws NoSuchAlgorithmException, KeyManagementException {

		// Set up a TrustManager that trusts everything
		final SSLContext sslContext = SSLContext.getInstance("SSL");
		sslContext.init(null, new TrustManager[] { new X509TrustManager() {
			@Override
			public X509Certificate[] getAcceptedIssuers() {
				return null;
			}

			@Override
			public void checkClientTrusted(X509Certificate[] certs, String authType) {
			}

			@Override
			public void checkServerTrusted(X509Certificate[] certs, String authType) {
			}
		} }, new SecureRandom());


		return sslContext;
	}

	/**
	 * Create SSL context
	 *
	 * @return
	 * @throws NoSuchAlgorithmException
	 * @throws KeyManagementException
	 */
	public static HttpClientBuilder createSSLHttpClientBuilder() throws KeyManagementException, NoSuchAlgorithmException {

		// Set up SSL connection manager and http client builder
		@SuppressWarnings("deprecation")
		final SSLConnectionSocketFactory sslConnectionSocketFactory = new SSLConnectionSocketFactory(createSSLContext(), SSLConnectionSocketFactory.ALLOW_ALL_HOSTNAME_VERIFIER);

		final Registry<ConnectionSocketFactory> registry = RegistryBuilder.<ConnectionSocketFactory> create()
				.register("https", sslConnectionSocketFactory).build();
		final HttpClientConnectionManager ccm = new BasicHttpClientConnectionManager(registry);
		final HttpClientBuilder builder = HttpClientBuilder.create();
		builder.setConnectionManager(ccm);

		return builder;
	}



}
