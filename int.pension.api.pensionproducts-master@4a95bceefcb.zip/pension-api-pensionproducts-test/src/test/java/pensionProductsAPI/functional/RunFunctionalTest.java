package pensionProductsAPI.functional;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(plugin = { "json:target/PensionProducts-functional.json"},
		features = "src/test/features/PensionProductsAPI",
		//glue = "lifeProtectionPoliciesAPI/functional",
		tags = { "~@inProgress","@executeThis" })
public class RunFunctionalTest {
}
