package pensionProductsAPI.functional;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import cucumber.api.java.Before;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import pensionProductsAPI.support.PensionProductsAPI;
import utility.PropertyReader;

public class StepDefinition {
	private static String url;
	String operationName = null;
	PensionProductsAPI pensionProductsAPI = new PensionProductsAPI();
	PropertyReader propertyReader = new PropertyReader();
	final static Logger logger = LoggerFactory.getLogger(StepDefinition.class);
	private String ActualVal = null;


	@Before
	public void initialize() throws Throwable {
		url = PensionProductsAPI.initialize();
		logger.debug("URL is:{}", url);
	}
	

	@Given("^the consumer requests \"(.*?)\"$")
	public void the_consumer_requests(String serviceOperationLabel) throws Throwable {
		String serviceOperationLabelKey = serviceOperationLabel.replace(" ",
				"_");
		// set the service operation
		String propertyKey = "functionToOperationTranslation."
				.concat(serviceOperationLabelKey);
		operationName = PropertyReader.getPropertyNotNull(propertyKey);
		System.out.println("OPeration Name : "+operationName);
	}
	
	
	@And("^a request contains \"(.*?)\" as \"(.*?)\"$")
	public void the_request_contains_as(String arg1, String value) throws Throwable {
		url = url + "/" + value ;
	logger.info("requestUrl :{}", url);
	}
	
	@When("^a HTTP GET request is made$")
	public void a_HTTP_GET_request_is_made() throws Throwable {
		PensionProductsAPI.httpGet("url");
	}

	@When("^a HTTPS GET request is made$")
	public void a_HTTPS_GET_request_is_made() throws Throwable {
		PensionProductsAPI.httpSecureGet(url);
	}

	

	@Then("^the HTTP response is \"(.*?)\"$")
	public void the_HTTP_response_is(String code) throws Throwable {
		switch (code) {
		case "200":
			assertEquals(200, PensionProductsAPI.getHttpStatusCode());
			break;
		case "403":
			assertEquals(403, PensionProductsAPI.getHttpStatusCode());
			break;
		case "400":
			assertEquals(400, PensionProductsAPI.getHttpStatusCode());	
			break;
		case "404":
			assertEquals(404, PensionProductsAPI.getHttpStatusCode());	
			break;
		case "500":
			assertEquals(500, PensionProductsAPI.getHttpStatusCode());	
			break;
		default:
			fail("unexpected http code " + code);
		}
	}
	
	@Then("^the JSON response contains \"(.*?)\" as \"(.*?)\"$")
	public void the_JSON_response_contains_as(String arg1, String arg2) throws Throwable {
		ActualVal = PensionProductsAPI.CheckResponseContent(operationName, arg1, arg2);
		assertEquals(arg2,ActualVal);
		System.out.println("Assertion is passed");
	}
	
	@Then("^the JSON response contains \"(.*?)\" as (\\d+)$")
	public void the_JSON_response_contains_as(String arg1, int arg2)
			throws Throwable {
		 int ActualVal = PensionProductsAPI.CheckResponseContent1(operationName, arg1, arg2);
		assertEquals(arg2, ActualVal);
		System.out.println("Assertion is passed");
	}
	
	@Then("^the HTTP response is (\\d+)$")
	public void the_HTTP_response_is(int responseCode) throws Throwable {
		assertEquals(responseCode, PensionProductsAPI.getHttpStatusCode());
	}

	@Given("^the requesting system is \"(.*?)\"$")
	public void the_requesting_system_is(String requestingSystem) throws Throwable {
		PensionProductsAPI.setRequestingSystem(requestingSystem);
	}
	
}