package pensionProductsAPI.support;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;

import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import utility.PropertyReader;
import environment.Environments;
import utility.HTTPUtil;

public class PensionProductsAPI {

	final static Logger logger = LoggerFactory.getLogger(PensionProductsAPI.class);

	//
	// Request data
	//
	private static final String HTTPS = "https";
	private static final String API_V1_PENSION_SCHEME_MEMBERS = "api/v1/pensionPlans";
	private static final String userName = "AppianAccount";
	private static final String password = "AppianAccount";
	
	private static final String HTTP_HEADER_ACCEPT = "application/json";
	private static final String HTTP_HEADER_CORRELATION_ID = "test";
	private static String HTTP_HEADER_AUTHORIZATION;
	public static String getHTTP_HEADER_AUTHORIZATION() {
		return HTTP_HEADER_AUTHORIZATION;
	}

	public static void setHTTP_HEADER_AUTHORIZATION(String hTTP_HEADER_AUTHORIZATION) {
		HTTP_HEADER_AUTHORIZATION = hTTP_HEADER_AUTHORIZATION;
	}
	
	
	private static JSONObject requestJson;

	//
	// Response data
	// TODO: Use JSONArray rather than JSONObject if needed
	//
	//private static String environment;
	private static int httpStatusCode;
	private static JSONObject responseJson;

	public static String initialize() {

		PensionProductsAPI.setBasicAuthCreds(userName, password);
		final String testEnvironment = System.getenv("TESTENVIRONMENT") == null ? "DEV" : System.getenv("TESTENVIRONMENT");
		final String applicationcontext = System.getenv("APPCONTEXT") == null ? API_V1_PENSION_SCHEME_MEMBERS : System
				.getenv("APPCONTEXT");
		String url = null;
		switch (testEnvironment.toUpperCase()) {
		case "DEV":
			url = Environments.DEV.generateURL();
			break;

		case "LOCAL":
			url = Environments.LOCAL_HTTP.generateURL();
			break;

		case "LOCAL_HTTPS":
			url = Environments.LOCAL_HTTPS.generateURL();
			break;
		}
		return url + applicationcontext;
	}

	
	public static void httpSecureGet(String URL) {
		HTTPUtil.httpGet(URL, HTTPS);
	}
	
	public static void setRequestingSystem(String requestingSystem) {
        HTTPUtil.setHttpHeaderRequestingSystem(requestingSystem);
      }
		

	public static void setBasicAuthCreds(String user, String password) {
		final String authHeader = HTTPUtil.getAuthorizationHeadder(user, password);
		HTTPUtil.setHTTP_HEADER_AUTHORIZATION(authHeader);
	}

	public static int getHttpStatusCode() {
		//PensionProductsAPI.httpStatusCode = httpStatusCode;
		return httpStatusCode;
	}
	public static void setHttpStatusCode(int httpStatusCode) {
		PensionProductsAPI.httpStatusCode = httpStatusCode;
	}
	public JSONObject getRequestJson() {
		return requestJson;
	}

	public void setRequestJson(JSONObject requestJson) {
		PensionProductsAPI.requestJson = requestJson;
	}

	public static void setResponseJson(JSONObject responseJson) {
		PensionProductsAPI.responseJson = responseJson;
	}
	
	/**
	 * Call the API using HTTP GET and save the response
	 * 
	 * @throws IOException
	 * @throws ClientProtocolException
	 * @throws NoSuchAlgorithmException
	 * @throws KeyManagementException
	 *             HttpPost httpPost = new HttpPost(
	 *             "https://utility-dev.integration.avivaaws.com:8443/api/v1/vehicles/YS11FZE/valuation"
	 *             );
	 */
	public static void httpGet(String protocol) throws ClientProtocolException,
			IOException, KeyManagementException, NoSuchAlgorithmException {

		// Create the HttpClient
		CloseableHttpClient httpClient;
		if (protocol.equals("http")) {
			httpClient = HttpClients.createDefault();
		} else {
			httpClient = HTTPUtil.createSSLHttpClientBuilder().build();
		}

		// Create the HttpGet
		HttpGet httpGet = new HttpGet(initialize());
		httpGet.setHeader("Accept", HTTP_HEADER_ACCEPT);
		httpGet.setHeader("Correlation-ID", HTTP_HEADER_CORRELATION_ID);
		httpGet.setHeader("Authorization", HTTP_HEADER_AUTHORIZATION);

		// Make the call and save results
		CloseableHttpResponse response = httpClient.execute(httpGet);
		String responseString = null;
		try {
			logger.info("httpGet Status Line {}", response.getStatusLine());
			httpStatusCode = response.getStatusLine().getStatusCode();
			if (httpStatusCode == 200) {
				responseString = EntityUtils.toString(response.getEntity());
				logger.info("httpGet Response {}", responseString);
				responseJson = new JSONObject(responseString);
			}
			
		} finally {
			response.close();
			httpClient.close();
		}
	}

	public static String CheckResponseContent(String operationName,String tagLabel,
			String expectedValue) throws Throwable {
		String ActualValue = null;
	   	String tag = tagLabel.replace(" ", "_");
		String[] arrStrings={""};
		// set the Json Path to the tag
		String propertyKey = operationName.concat(".response.jsonPath.")
			.concat(tag);   
		String jsonPath = PropertyReader
				.getPropertyNotNull(propertyKey);
		
		//Spliting Json Path to evaluate objects/tags
		if (jsonPath.contains("/"))
		{
	
		arrStrings = jsonPath.split("/");
		}
		else 
			{
			 arrStrings[0]=jsonPath;
			}
			
		JSONObject objres = responseJson;
		//iterate through json path to each object 
		for(int i=0;i<arrStrings.length;i++){
			//If current json object is not the leaf node
			if(i < arrStrings.length-1){
				
				//checking if Json Path contains any array object
				if (arrStrings[i].contains("[")){
					int startindex=arrStrings[i].indexOf("[");
					int endindex=arrStrings[i].indexOf("]");
					//Get name of object and its count in array in separate variables
					int baseIndex=Integer.parseInt(arrStrings[i].substring(startindex+1, endindex));
					String objname=arrStrings[i].substring(0, startindex);
					JSONArray j1=objres.getJSONArray(objname);
					objres=j1.getJSONObject(baseIndex);
				}
				//IF object is not an array
				else 
				{
					System.out.println("OBject is :::"+ (String) objres.getString("planNumber"));
					objres=  objres.getJSONObject(arrStrings[i]) ;
					System.out.println("OBject is After:::"+objres);
				}
			}else 				
				//If current Json object is the leaf node
				if(i==arrStrings.length-1){
					
					//Read actual value of the tag
					
					String str=arrStrings[i];
					
					try{
						ActualValue = objres.getString(str);
					}catch(JSONException e)
					{
						System.out.println("Exception on object "+ objres);
						//ActualValue = objres.getDouble(str);
						ActualValue = JSONObject.doubleToString(objres.getDouble(str));
						
					}
			//	ActualValue = (String) objres.getInt((arrStrings[i]));
				
				System.out.println("Actual Value is of "+tagLabel +" is : "+ActualValue);
				}			
		}
		return ActualValue;
	
	}
	
	
	public static int CheckResponseContent1(String operationName, String tagLabel, int expectedValue) throws Throwable {
		int ActualValue = 0;
		String tag = tagLabel.replace(" ", "_");
		String[] arrStrings = { "" };
		// set the Json Path to the tag
		String propertyKey = operationName.concat(".response.jsonPath.")
				.concat(tag);
		String jsonPath = PropertyReader.getPropertyNotNull(propertyKey);

		// Spliting Json Path to evaluate objects/tags
		if (jsonPath.contains("/")) {

			arrStrings = jsonPath.split("/");
		} else {
			arrStrings[0] = jsonPath;
		}

		JSONObject objres = responseJson;
		// iterate through json path to each object
		for (int i = 0; i < arrStrings.length; i++) {
			// If current json object is not the leaf node
			if (i < arrStrings.length - 1) {

				// checking if Json Path contains any array object
				if (arrStrings[i].contains("[")) {
					int startindex = arrStrings[i].indexOf("[");
					int endindex = arrStrings[i].indexOf("]");
					// Get name of object and its count in array in seperate
					// variables
					int baseIndex = Integer.parseInt(arrStrings[i].substring(
							startindex + 1, endindex));
					String objname = arrStrings[i].substring(0, startindex);
					JSONArray j1 = objres.getJSONArray(objname);
					objres = j1.getJSONObject(baseIndex);
				}
				// IF object is not an array
				else {
					objres = objres.getJSONObject(arrStrings[i]);

				}
			} else
			// If current Json object is the leaf node
			if (i == arrStrings.length - 1) {
				ActualValue = (int) objres.getInt((arrStrings[i]));

				System.out.println("Actual Value is of " + tagLabel + " is : "
						+ ActualValue);
			}
		}
		return ActualValue;
	}
	
}
