package com.aviva.uk.integration.pensionproducts.stub;

import javax.ws.rs.PathParam;
import javax.ws.rs.core.Response.Status;

import org.apache.camel.Exchange;
import org.apache.cxf.message.MessageContentsList;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.aviva.uk.integration.errorhandling.ProblemDetailsException;

public class RestHandler {
	private static Logger log = LoggerFactory.getLogger(DynamicStub.class);

	public void setBody(@PathParam("planNumber") String planNumber, Exchange exchange) throws Exception {

		MessageContentsList request = exchange.getIn().getBody(MessageContentsList.class);
		log.debug("PensionProductsMock :: RestHandler :: Start");

		log.debug("planNumber: " + planNumber);

		try {
			if (planNumber.isEmpty()) {
				throw new ProblemDetailsException(Status.FORBIDDEN, "Resource Not available for requested parameter");
			} else {
				exchange.getIn().setBody(planNumber);
			}
		} catch (Exception e) {
			throw new ProblemDetailsException(Status.INTERNAL_SERVER_ERROR, "PensionProductsMock error");
		}
	}
}
