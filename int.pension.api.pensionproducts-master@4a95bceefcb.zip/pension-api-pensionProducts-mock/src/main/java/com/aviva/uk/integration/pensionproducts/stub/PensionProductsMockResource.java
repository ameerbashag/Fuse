package com.aviva.uk.integration.pensionproducts.stub;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

public class PensionProductsMockResource {

	@GET
	@Path("/{planNumber}/pensionProducts")
	@Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML, MediaType.TEXT_XML, "application/problem+json" })
	@Consumes({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML, MediaType.TEXT_XML, "application/problem+json" })
	public Object pensionProducts(@PathParam("planNumber") String planNumber) {
		return null;
	}

}
