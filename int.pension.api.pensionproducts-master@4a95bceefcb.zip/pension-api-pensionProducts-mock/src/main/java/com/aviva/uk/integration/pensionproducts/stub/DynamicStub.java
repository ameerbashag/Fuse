package com.aviva.uk.integration.pensionproducts.stub;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Properties;
import java.util.Random;
import java.util.Set;

import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.Response;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.xpath.XPathExpressionException;

import org.apache.camel.Exchange;
import org.apache.log4j.MDC;
import org.apache.ws.security.util.UUIDGenerator;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.xml.sax.SAXException;

import com.aviva.uk.integration.headers.ESBMetaDataHandler;
import com.aviva.uk.integration.logging.MDCConstants;

public class DynamicStub {

	public static final String DEFAULT_STUB = "default";

	// delay property in the config - in milliseconds
	public static final String DELAY = "delay";

	protected static final String XPATH = "key";

	public static final String ESB_METADATA_DELAY = ESBMetaDataHandler.ESB_METADATA_PREFIX + "DelayTime";

	private static Logger log = LoggerFactory.getLogger(DynamicStub.class);

	private String configFile;

	private static Map<String, String> responseMap = Collections.synchronizedMap(new HashMap<String, String>());

	private static Properties cachedProperties = null;
	private static Response response = null;

	public String getConfigFile() {
		return configFile;
	}

	public void setConfigFile(String configFile) {
		this.configFile = configFile;
		log.debug("config file set to: " + this.configFile);
	}

	/**
	 * Returns a stubbed response message using the following criteria: 1. if XPATH parameter is configured and there is
	 * a stub with a name that matches the xpath result, return that stub 2. return the default stub if configured 3.
	 * randomly return one of the configured stubs
	 *
	 * @param exchange
	 * @throws Exception
	 */

	public void setResponseMessage(Exchange exchange) throws Exception {

		// This is a NEW GUID (will not match service - i.e. invoker - GUID)
		String guid = UUIDGenerator.getUUID();
		MDC.put(MDCConstants.ESB_GUID, guid);

		log.debug("Dynamic stub : setResponseMessage start");

		Map<String, Object> temp1 = exchange.getIn().getHeaders();

		Set keys1 = temp1.keySet();
		Iterator it1 = keys1.iterator();
		while (it1.hasNext()) {
			String strkey1 = (String) it1.next();
			log.debug("--->header before :" + strkey1 + " value : " + temp1.get(strkey1));
		}

		exchange.getIn().removeHeader("authorization");
		exchange.getIn().removeHeaders("Camel*");
		exchange.getIn().removeHeader(HttpHeaders.ACCEPT);
		exchange.getIn().removeHeader(Exchange.ACCEPT_CONTENT_TYPE);

		String message = exchange.getIn().getBody(String.class);
		String stubFileName = getStubFileName(message);
		response = getStubResponseMsg(stubFileName);

		if (stubFileName.contains("ER")) {
			response = Response.status(500).entity(response).build();
		}

		exchange.getIn().setBody(response);
		exchange.getIn().setHeader(Exchange.CONTENT_TYPE, "application/json; charset=utf-8");
		exchange.getIn().setHeader(Exchange.CONTENT_ENCODING, "UTF-8");
		exchange.getIn().setHeader(Exchange.ACCEPT_CONTENT_TYPE, "application/json");

		log.debug("Dynamic stub : setResponseMessage after");

		Map<String, Object> temp = exchange.getIn().getHeaders();

		Set keys = temp.keySet();
		Iterator it = keys.iterator();
		while (it.hasNext()) {
			String strkey = (String) it.next();
			log.debug("header after :" + strkey + " value : " + temp.get(strkey));
		}

		log.debug("Dynamic stub : setResponseMessage end");
		log.debug("Dynamic stub : Finish");

	}

	@SuppressWarnings("unchecked")
	protected void delayResponse(Exchange exchange, long configDelay) {

		log.debug("Delay time passed from the service config: " + configDelay);

		HashMap<String, String> esbMetaDataHeaders = (HashMap<String, String>) exchange
				.getProperty(ESBMetaDataHandler.ESB_METADATA_PROPERTY_NAME);

		if (esbMetaDataHeaders != null) {
			String delayTime = esbMetaDataHeaders.get(ESB_METADATA_DELAY);
			log.debug("Reading delay time from header : " + delayTime);
			try {
				if (delayTime != null && delayTime.length() > 0) {
					try {
						configDelay = Long.parseLong(delayTime);

					} catch (NumberFormatException n) {
						log.error(n.getMessage());
					}
				}
			} catch (Exception e) {
				log.error(e.getMessage());
			}
		}

		try {
			if (configDelay > 0) {
				log.debug("Service stub is sleeping for " + configDelay + " milliseconds");
				Thread.sleep(configDelay);
			}
		} catch (Exception e) {
			log.error(e.getMessage());
		}

	}

	protected Response getStubResponseMsg(String stubFileName) throws IOException {

		StringBuffer stub = new StringBuffer();
		InputStream fis = null;

		fis = this.getClass().getResourceAsStream(stubFileName);
		if (fis == null) {
			stubFileName = "/stubs/default";
			fis = this.getClass().getResourceAsStream(stubFileName);
			BufferedReader br = new BufferedReader(new InputStreamReader(fis));
			String record = new String();
			while ((record = br.readLine()) != null) {
				stub.append(record);
			}
			response = Response.status(404).entity(stub.toString()).build();
		} else {
			BufferedReader br = new BufferedReader(new InputStreamReader(fis));
			String record = new String();
			while ((record = br.readLine()) != null) {
				stub.append(record);
			}
			log.debug("PensionProducts :: response returned");
			response = Response.status(200).entity(stub.toString()).build();
		}
		return response;
	}

	protected String chooseRandomStub(Properties properties) {
		String stubName;
		Random random = new Random();
		stubName = (String) properties.keySet().toArray()[random.nextInt(properties.keySet().size())];
		log.debug("randomly chosen stub " + stubName);
		return stubName;
	}

	protected void setKeysToLowercase(Properties properties) {
		Object[] propertiesKeys = properties.keySet().toArray();

		// make sure we are looking only at properties that are defining stubs
		for (Object key : propertiesKeys) {
			// make sure that all keys are lower case
			String value = (String) properties.get(key);
			properties.remove(key);
			properties.put(((String) key).toLowerCase(), value);

		}
	}

	protected String getStubNameFromXPath(String message) throws XPathExpressionException, SAXException, IOException,
			ParserConfigurationException, UnsupportedEncodingException {
		String stubName;
		stubName = message;
		log.debug("value of the evaluated xpath = " + stubName);
		if (stubName != null && stubName.length() == 0)
			stubName = null;
		log.debug("stub based on xpath " + stubName);
		return stubName;
	}

	protected synchronized Properties loadStubProperties(boolean useCache) throws IOException {
		if (cachedProperties != null && useCache)
			return cachedProperties;
		Properties properties = new Properties();
		InputStream in = this.getClass().getResourceAsStream(getConfigFile());
		properties.load(in);
		setKeysToLowercase(properties);
		log.debug("properties loaded...");
		if (useCache)
			cachedProperties = properties;
		return properties;
	}

	protected String getStubFileName(String message) {
		String stubName = null;

		log.debug("planNumber: " + message);

		try {
			stubName = getStubNameFromXPath(message);
		} catch (Exception e) {
			log.error(e.getMessage());
		}

		String stubFileName = "/stubs/" + stubName;

		log.debug("stub file name " + stubFileName);
		return stubFileName;

	}
}
