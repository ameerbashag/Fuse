/**
 * 
 */
package com.eai.integration.swagger;

import javax.xml.bind.annotation.XmlRootElement;

/**
 * @author bashaa
 *
 */
@XmlRootElement(name="SwaggerResponse")
public class SwaggerResponse {

	private String responseMessage;

	public String getResponseMessage() {
		return responseMessage;
	}

	public void setResponseMessage(String responseMessage) {
		this.responseMessage = responseMessage;
	}
}
