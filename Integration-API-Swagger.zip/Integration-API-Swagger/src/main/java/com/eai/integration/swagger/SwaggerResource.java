package com.eai.integration.swagger;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;


/**
 * This class is used to take the request from user.
 * 
 * 
 * @author AKSHAJ
 * 
 */

@Path("/camelSwagger")
@Api(value = "camelSwagger")
@Produces({"application/json", "application/xml"})
public class SwaggerResource {

	public SwaggerResource() {
	}

	 @GET
	 @Path("/{message}")
	 @ApiOperation(value = "getMessage",
	    notes = "get the response message",
	    response = SwaggerResponse.class,
	    responseContainer = "List")
	public SwaggerResponse getMessage(@ApiParam(value = "name that need to be updated", required = true)  @PathParam("message") String message) {
		// this does nothing -- just a shell for CXF and Camel
		SwaggerResponse swaggerResponse = new SwaggerResponse();
		swaggerResponse.setResponseMessage("Hello "+message);
		return swaggerResponse;
	}
	

}
